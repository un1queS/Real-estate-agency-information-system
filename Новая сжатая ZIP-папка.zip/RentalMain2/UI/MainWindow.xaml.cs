﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Microsoft.Win32;
using RentalMain2.Models;
using System.Data;

namespace RentalMain2.UI;

public partial class MainWindow : Window
{
    private bool IsAdmin => string.Equals(App.CurrentUser?.Role, "Admin", StringComparison.OrdinalIgnoreCase);
    private bool CanEditData => IsAdmin || (App.CurrentUser?.CanEdit ?? false);

    private int _suppressComboPersist;
    private int _suppressFormFill;

    public MainWindow()
    {
        InitializeComponent();
        WireGridHeaderTranslations();
        Loaded += MainWindow_Loaded;
    }

    private void WireGridHeaderTranslations()
    {
        DgClients.AutoGeneratingColumn += DataGrid_OnAutoGeneratingColumn;
        DgProperties.AutoGeneratingColumn += DataGrid_OnAutoGeneratingColumn;
        DgDeals.AutoGeneratingColumn += DataGrid_OnAutoGeneratingColumn;
        DgAllTablesData.AutoGeneratingColumn += DataGrid_OnAutoGeneratingColumn;
        DgUsers.AutoGeneratingColumn += DataGrid_OnAutoGeneratingColumn;
    }

    private static readonly Dictionary<string, string> ColumnHeaderMap = new(StringComparer.OrdinalIgnoreCase)
    {
        // Clients
        ["ClientID"] = "ID клиента",
        ["FullName"] = "ФИО",
        ["Phone"] = "Телефон",
        ["Email"] = "Email",
        ["ClientType"] = "Тип клиента",

        // Properties
        ["PropertyID"] = "ID объекта",
        ["Address"] = "Адрес",
        ["PropertyType"] = "Тип объекта",
        ["Area"] = "Площадь",
        ["Rooms"] = "Комнат",
        ["Floor"] = "Этаж",
        ["Price"] = "Цена",
        ["Status"] = "Статус",
        ["OwnerID"] = "ID владельца",

        // Deals
        ["DealID"] = "ID сделки",
        ["DealType"] = "Тип сделки",
        ["Amount"] = "Сумма",
        ["DealDate"] = "Дата",

        // Users
        ["UserID"] = "ID пользователя",
        ["Login"] = "Логин",
        ["Password"] = "Пароль",
        ["Role"] = "Роль",
        ["CanEdit"] = "Редактирование",
        ["IsActive"] = "Активен",
    };

    private void DataGrid_OnAutoGeneratingColumn(object? sender, DataGridAutoGeneratingColumnEventArgs e)
    {
        string key = e.PropertyName?.Trim() ?? string.Empty;
        if (string.IsNullOrWhiteSpace(key))
        {
            return;
        }

        if (ColumnHeaderMap.TryGetValue(key, out var translated))
        {
            e.Column.Header = translated;
        }
        else
        {
            e.Column.Header = key;
        }

        if (e.Column is DataGridTextColumn textCol && string.Equals(key, "DealDate", StringComparison.OrdinalIgnoreCase))
        {
            if (textCol.Binding is Binding b)
            {
                b.StringFormat = "dd.MM.yyyy";
            }
            else
            {
                textCol.Binding = new Binding(key) { StringFormat = "dd.MM.yyyy" };
            }
        }
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        _suppressComboPersist++;
        try
        {
            // Устанавливаем значения по умолчанию, чтобы форма не падала при первом вводе.
            if (CbClientType.SelectedIndex < 0 && CbClientType.Items.Count > 0)
            {
                CbClientType.SelectedIndex = 0;
            }
            if (CbDealTypeComplete.SelectedIndex < 0 && CbDealTypeComplete.Items.Count > 0)
            {
                CbDealTypeComplete.SelectedIndex = 0;
            }
            if (CbUserRole.SelectedIndex < 0 && CbUserRole.Items.Count > 0)
            {
                CbUserRole.SelectedIndex = 0;
            }
            EnsureComboDefault(CbPropertyType);
            EnsureComboDefault(CbPropertyStatus);
            EnsureComboDefault(CbDealType);
            EnsureComboDefault(CbDealStatus);
            EnsureComboDefault(CbSearchType);
            DpDealDate.SelectedDate ??= DateTime.Today;
            DateTime today = DateTime.Today;
            DpStartDate.SelectedDate ??= new DateTime(today.Year, today.Month, 1);
            DpEndDate.SelectedDate ??= today;
        }
        finally
        {
            _suppressComboPersist--;
        }

        TbCurrentUserInfo.Text = App.CurrentUser is null
            ? "Пользователь: не определен"
            : $"Пользователь: {App.CurrentUser.Login} | Роль: {GetRoleTitle(App.CurrentUser.Role)} | Редактирование: {(CanEditData ? "Да" : "Нет")}";

        TabUsersAdmin.Visibility = IsAdmin ? Visibility.Visible : Visibility.Collapsed;

        await SafeRunAsync(ReloadAllAsync, "Ошибка загрузки данных");
    }

    private async Task ReloadAllAsync()
    {
        await LoadDashboardAsync();
        await LoadClientsAsync();
        await LoadPropertiesAsync();
        await LoadDealsAsync();
        await LoadDealSourcesAsync();
        await LoadAllTablesListAsync();
        if (IsAdmin)
        {
            await LoadUsersAsync();
        }
    }

    private async Task LoadDashboardAsync()
    {
        if (App.Repository is null) return;
        DashboardSummary summary = await App.Repository.GetDashboardSummaryAsync();
        BindDashboard(summary);
    }

    private void BindDashboard(DashboardSummary summary)
    {
        TbDashClients.Text = summary.ClientsCount.ToString();
        TbDashProperties.Text = summary.PropertiesCount.ToString();
        TbDashActiveProperties.Text = summary.ActivePropertiesCount.ToString();
        TbDashDeals.Text = summary.DealsCount.ToString();
        TbDashDealsMonth.Text = summary.DealsThisMonthCount.ToString();
        TbDashDealsMonthAmount.Text = $"Сумма: {summary.DealsThisMonthAmount:N2} ₽";
        TbDashDealTypes.Text = $"{summary.SalesDealsCount} / {summary.RentDealsCount}";
        TbDashboardUpdated.Text = $"Обновлено: {DateTime.Now:dd.MM.yyyy HH:mm}";
    }

    private async void BtnRefreshDashboard_OnClick(object sender, RoutedEventArgs e) =>
        await SafeRunAsync(LoadDashboardAsync, "Ошибка обновления сводки");

    private async Task LoadUsersAsync()
    {
        if (App.Repository is null || !IsAdmin) return;
        DgUsers.ItemsSource = await App.Repository.GetAllUsersAsync();
    }

    private async Task LoadClientsAsync()
    {
        if (App.Repository is null) return;
        _suppressComboPersist++;
        try
        {
            var clients = await App.Repository.GetClientsAsync();
            DgClients.ItemsSource = clients;
            CbClientsForDeal.ItemsSource = clients;
            CbClientReport.ItemsSource = clients;
            CbPropertyOwner.ItemsSource = clients;
            CbDealClient.ItemsSource = clients;
        }
        finally
        {
            _suppressComboPersist--;
        }
    }

    private async Task LoadPropertiesAsync()
    {
        if (App.Repository is null) return;
        var properties = await App.Repository.GetPropertiesAsync();
        DgProperties.ItemsSource = properties;
        CbDealProperty.ItemsSource = properties;
    }

    private async Task LoadDealsAsync()
    {
        if (App.Repository is null) return;
        DgDeals.ItemsSource = await App.Repository.GetDealsAsync();
    }

    private async Task LoadDealSourcesAsync()
    {
        if (App.Repository is null) return;
        CbActiveProperties.ItemsSource = await App.Repository.GetActivePropertiesAsync();
    }

    private async Task LoadAllTablesListAsync()
    {
        if (App.Repository is null) return;
        var tables = await App.Repository.GetAllUserTableNamesAsync();
        CbAllTables.ItemsSource = tables;
        if (tables.Count > 0)
        {
            CbAllTables.SelectedIndex = 0;
        }
        else
        {
            DgAllTablesData.ItemsSource = null;
        }
    }

    private async Task LoadSelectedTableDataAsync()
    {
        if (App.Repository is null) return;
        if (CbAllTables.SelectedItem is not string tableName || string.IsNullOrWhiteSpace(tableName))
        {
            DgAllTablesData.ItemsSource = null;
            return;
        }

        DataTable data = await App.Repository.GetTableDataAsync(tableName);
        DgAllTablesData.ItemsSource = data.DefaultView;
    }

    private async Task SafeRunAsync(Func<Task> action, string operationName)
    {
        try
        {
            await action();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"{operationName}: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private async void BtnClientsRefresh_OnClick(object sender, RoutedEventArgs e) =>
        await SafeRunAsync(LoadClientsAsync, "Ошибка загрузки клиентов");

    private async void BtnClientAdd_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureCanEditData()) return;
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            await App.Repository.AddClientAsync(new Client
            {
                FullName = TbClientName.Text.Trim(),
                Phone = TbClientPhone.Text.Trim(),
                Email = TbClientEmail.Text.Trim(),
                ClientType = ReadComboText(CbClientType, "Тип клиента")
            });
            await LoadClientsAsync();
            await LoadDashboardAsync();
            ClearClientForm();
        }, "Ошибка добавления клиента");
    }

    private async void BtnClientUpdate_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureCanEditData()) return;
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            Client client = RequireSelectedClient();
            client.FullName = TbClientName.Text.Trim();
            client.Phone = TbClientPhone.Text.Trim();
            client.Email = TbClientEmail.Text.Trim();
            client.ClientType = ReadComboText(CbClientType, "Тип клиента");
            await App.Repository.UpdateClientAsync(client);
            await LoadClientsAsync();
            ReselectClient(client.ClientID);
        }, "Ошибка обновления клиента");
    }

    private async void BtnClientDelete_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureCanEditData()) return;
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            int clientId = RequireSelectedClient().ClientID;
            await App.Repository.DeleteClientAsync(clientId);
            await LoadClientsAsync();
            ClearClientForm();
        }, "Ошибка удаления клиента");
    }

    private async void BtnPropertiesRefresh_OnClick(object sender, RoutedEventArgs e) =>
        await SafeRunAsync(async () =>
        {
            await LoadPropertiesAsync();
            await LoadDealSourcesAsync();
        }, "Ошибка загрузки объектов");

    private async void BtnPropertyAdd_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureCanEditData()) return;
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            await App.Repository.AddPropertyAsync(ReadProperty());
            await LoadPropertiesAsync();
            await LoadDealSourcesAsync();
            await LoadDashboardAsync();
            ClearPropertyForm();
        }, "Ошибка добавления объекта");
    }

    private async void BtnPropertyUpdate_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureCanEditData()) return;
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            Property property = ReadProperty();
            property.PropertyID = RequireSelectedProperty().PropertyID;
            await App.Repository.UpdatePropertyAsync(property);
            await LoadPropertiesAsync();
            await LoadDealSourcesAsync();
            ReselectProperty(property.PropertyID);
        }, "Ошибка обновления объекта");
    }

    private async void BtnPropertyDelete_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureCanEditData()) return;
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            int propertyId = RequireSelectedProperty().PropertyID;
            await App.Repository.DeletePropertyAsync(propertyId);
            await LoadPropertiesAsync();
            await LoadDealSourcesAsync();
            ClearPropertyForm();
        }, "Ошибка удаления объекта");
    }

    private async void BtnPropertySearch_OnClick(object sender, RoutedEventArgs e)
    {
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            string type = ReadOptionalComboText(CbSearchType);
            decimal? minPrice = ParseNullableDecimal(TbSearchMinPrice.Text);
            decimal? maxPrice = ParseNullableDecimal(TbSearchMaxPrice.Text);
            int? rooms = ParseNullableInt(TbSearchRooms.Text);
            DgProperties.ItemsSource = await App.Repository.SearchPropertiesAsync(type, minPrice, maxPrice, rooms);
        }, "Ошибка поиска объектов");
    }

    private async void BtnPropertyShowActive_OnClick(object sender, RoutedEventArgs e)
    {
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            DgProperties.ItemsSource = await App.Repository.GetActivePropertiesAsync();
        }, "Ошибка загрузки активных объектов");
    }

    private async void BtnDealsRefresh_OnClick(object sender, RoutedEventArgs e) =>
        await SafeRunAsync(LoadDealsAsync, "Ошибка загрузки сделок");

    private async void BtnDealAdd_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureCanEditData()) return;
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            await App.Repository.AddDealAsync(ReadDeal());
            await LoadDealsAsync();
            await LoadDashboardAsync();
            ClearDealForm();
        }, "Ошибка добавления сделки");
    }

    private async void BtnDealUpdate_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureCanEditData()) return;
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            Deal deal = ReadDeal();
            deal.DealID = RequireSelectedDeal().DealID;
            await App.Repository.UpdateDealAsync(deal);
            await LoadDealsAsync();
            ReselectDeal(deal.DealID);
        }, "Ошибка обновления сделки");
    }

    private async void BtnDealDelete_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureCanEditData()) return;
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            int dealId = RequireSelectedDeal().DealID;
            await App.Repository.DeleteDealAsync(dealId);
            await LoadDealsAsync();
            ClearDealForm();
        }, "Ошибка удаления сделки");
    }

    private async void BtnCompleteDeal_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureCanEditData()) return;
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            if (CbActiveProperties.SelectedItem is not Property property)
            {
                throw new InvalidOperationException("Выберите активный объект.");
            }
            if (CbClientsForDeal.SelectedItem is not Client client)
            {
                throw new InvalidOperationException("Выберите клиента.");
            }

            string dealType = ReadComboText(CbDealTypeComplete, "Тип сделки");
            decimal amount = ParseDecimal(TbDealCompleteAmount.Text, "Сумма");
            await App.Repository.CreateCompletedDealAsync(property.PropertyID, client.ClientID, dealType, amount);

            await LoadDealsAsync();
            await LoadPropertiesAsync();
            await LoadDealSourcesAsync();
            await LoadDashboardAsync();
            MessageBox.Show("Сделка оформлена успешно.", "Готово", MessageBoxButton.OK, MessageBoxImage.Information);
        }, "Ошибка оформления сделки");
    }

    private async void BtnReportPeriod_OnClick(object sender, RoutedEventArgs e)
    {
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            if (!DpStartDate.SelectedDate.HasValue || !DpEndDate.SelectedDate.HasValue)
            {
                throw new InvalidOperationException("Укажите обе даты периода.");
            }
            var rows = await App.Repository.GetDealsReportByPeriodAsync(
                DpStartDate.SelectedDate.Value,
                DpEndDate.SelectedDate.Value);
            LbPeriodReport.ItemsSource = rows;
        }, "Ошибка формирования отчета по периоду");
    }

    private async void BtnReportClient_OnClick(object sender, RoutedEventArgs e)
    {
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            if (CbClientReport.SelectedItem is not Client client)
            {
                throw new InvalidOperationException("Выберите клиента.");
            }
            LbClientReport.ItemsSource = await App.Repository.GetClientDealsReportAsync(client.ClientID);
        }, "Ошибка формирования отчета по клиенту");
    }

    private void BtnExportPeriodReport_OnClick(object sender, RoutedEventArgs e)
    {
        try
        {
            string header = BuildPeriodReportHeader();
            ExportReportToFile(LbPeriodReport, "otchet_period", header);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка экспорта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnExportClientReport_OnClick(object sender, RoutedEventArgs e)
    {
        try
        {
            string header = BuildClientReportHeader();
            ExportReportToFile(LbClientReport, "otchet_klient", header);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка экспорта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private string BuildPeriodReportHeader()
    {
        string start = DpStartDate.SelectedDate?.ToString("dd.MM.yyyy") ?? "—";
        string end = DpEndDate.SelectedDate?.ToString("dd.MM.yyyy") ?? "—";
        return $"Отчет по сделкам за период: {start} — {end}";
    }

    private string BuildClientReportHeader()
    {
        string clientName = CbClientReport.SelectedItem is Client client
            ? client.FullName
            : "не выбран";
        return $"Отчет по клиенту: {clientName}";
    }

    private static void ExportReportToFile(ListBox listBox, string defaultFileName, string header)
    {
        if (listBox.Items.Count == 0)
        {
            throw new InvalidOperationException("Сначала сформируйте отчет.");
        }

        var dialog = new SaveFileDialog
        {
            Title = "Сохранить отчет",
            Filter = "Текстовый файл (*.txt)|*.txt|CSV (*.csv)|*.csv",
            FileName = $"{defaultFileName}_{DateTime.Now:yyyyMMdd_HHmmss}",
            DefaultExt = ".txt"
        };

        if (dialog.ShowDialog() != true)
        {
            return;
        }

        bool asCsv = dialog.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase);
        var lines = new List<string> { header, new string('-', Math.Min(header.Length, 80)) };
        foreach (object item in listBox.Items)
        {
            lines.Add(item?.ToString() ?? string.Empty);
        }

        string content = asCsv ? ConvertReportLinesToCsv(lines) : string.Join(Environment.NewLine, lines);
        File.WriteAllText(dialog.FileName, content, new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
        MessageBox.Show($"Отчет сохранен:\n{dialog.FileName}", "Экспорт", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private static string ConvertReportLinesToCsv(IEnumerable<string> lines)
    {
        var sb = new StringBuilder();
        foreach (string line in lines)
        {
            string escaped = line.Contains('"') ? line.Replace("\"", "\"\"") : line;
            if (escaped.Contains(';') || escaped.Contains('"') || escaped.Contains('\n'))
            {
                escaped = $"\"{escaped}\"";
            }
            sb.AppendLine(escaped);
        }
        return sb.ToString();
    }

    private async void BtnRefreshAllTables_OnClick(object sender, RoutedEventArgs e)
    {
        await SafeRunAsync(LoadAllTablesListAsync, "Ошибка загрузки списка таблиц");
    }

    private async void CbAllTables_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        await SafeRunAsync(LoadSelectedTableDataAsync, "Ошибка загрузки таблицы");
    }

    private void DgClients_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressFormFill > 0)
        {
            return;
        }

        if (DgClients.SelectedItem is Client client)
        {
            FillClientForm(client);
        }
    }

    private void DgProperties_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressFormFill > 0)
        {
            return;
        }

        if (DgProperties.SelectedItem is Property property)
        {
            FillPropertyForm(property);
        }
    }

    private void DgDeals_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressFormFill > 0)
        {
            return;
        }

        if (DgDeals.SelectedItem is Deal deal)
        {
            FillDealForm(deal);
        }
    }

    private void DgUsers_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressFormFill > 0)
        {
            return;
        }

        if (DgUsers.SelectedItem is User user)
        {
            FillUserForm(user);
        }
    }

    private async void ComboPersistClient_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressComboPersist > 0)
        {
            return;
        }

        if (!EnsureCanEditData())
        {
            return;
        }

        await SafeRunAsync(TryPersistCurrentClientAsync, "Ошибка сохранения клиента");
    }

    private async void ComboPersistUserRole_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressComboPersist > 0)
        {
            return;
        }

        if (!EnsureIsAdmin())
        {
            return;
        }

        await SafeRunAsync(TryPersistCurrentUserPermissionsAsync, "Ошибка сохранения роли пользователя");
    }

    private async Task TryPersistCurrentClientAsync()
    {
        if (App.Repository is null)
        {
            return;
        }

        if (DgClients.SelectedItem is not Client client)
        {
            return;
        }

        client.FullName = TbClientName.Text.Trim();
        client.Phone = TbClientPhone.Text.Trim();
        client.Email = TbClientEmail.Text.Trim();
        client.ClientType = ReadComboText(CbClientType, "Тип клиента");
        await App.Repository.UpdateClientAsync(client);
        await LoadClientsAsync();
        ReselectClient(client.ClientID);
    }

    private async Task TryPersistCurrentUserPermissionsAsync()
    {
        if (App.Repository is null)
        {
            return;
        }

        if (DgUsers.SelectedItem is not User user)
        {
            return;
        }

        string role = ReadRoleValue(CbUserRole);
        bool canEdit = ChbUserCanEdit.IsChecked == true;
        bool isActive = ChbUserIsActive.IsChecked == true;

        await App.Repository.UpdateUserPermissionsAsync(user.UserID, role, canEdit, isActive);
        await LoadUsersAsync();
        ReselectUser(user.UserID);
    }

    private async void BtnUsersRefresh_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureIsAdmin()) return;
        await SafeRunAsync(LoadUsersAsync, "Ошибка загрузки пользователей");
    }

    private async void BtnUserApplyRights_OnClick(object sender, RoutedEventArgs e)
    {
        if (!EnsureIsAdmin()) return;
        await SafeRunAsync(async () =>
        {
            if (App.Repository is null) return;
            User user = RequireSelectedUser();
            string role = ReadRoleValue(CbUserRole);
            bool canEdit = ChbUserCanEdit.IsChecked == true;
            bool isActive = ChbUserIsActive.IsChecked == true;

            await App.Repository.UpdateUserPermissionsAsync(user.UserID, role, canEdit, isActive);
            await LoadUsersAsync();
            ReselectUser(user.UserID);
        }, "Ошибка обновления прав пользователя");
    }

    private Client RequireSelectedClient()
    {
        if (DgClients.SelectedItem is Client client)
        {
            return client;
        }

        throw new InvalidOperationException("Выберите клиента в таблице для изменения или удаления.");
    }

    private Property RequireSelectedProperty()
    {
        if (DgProperties.SelectedItem is Property property)
        {
            return property;
        }

        throw new InvalidOperationException("Выберите объект в таблице для изменения или удаления.");
    }

    private Deal RequireSelectedDeal()
    {
        if (DgDeals.SelectedItem is Deal deal)
        {
            return deal;
        }

        throw new InvalidOperationException("Выберите сделку в таблице для изменения или удаления.");
    }

    private User RequireSelectedUser()
    {
        if (DgUsers.SelectedItem is User user)
        {
            return user;
        }

        throw new InvalidOperationException("Выберите пользователя в таблице.");
    }

    private void FillClientForm(Client client)
    {
        _suppressComboPersist++;
        _suppressFormFill++;
        try
        {
            TbClientName.Text = client.FullName;
            TbClientPhone.Text = client.Phone;
            TbClientEmail.Text = client.Email;
            SelectComboItemByContent(CbClientType, client.ClientType);
        }
        finally
        {
            _suppressFormFill--;
            _suppressComboPersist--;
        }
    }

    private void ClearClientForm()
    {
        _suppressComboPersist++;
        _suppressFormFill++;
        try
        {
            DgClients.SelectedItem = null;
            TbClientName.Clear();
            TbClientPhone.Clear();
            TbClientEmail.Clear();
            EnsureComboDefault(CbClientType);
        }
        finally
        {
            _suppressFormFill--;
            _suppressComboPersist--;
        }
    }

    private void FillPropertyForm(Property property)
    {
        _suppressFormFill++;
        try
        {
            TbPropertyAddress.Text = property.Address;
            TbPropertyArea.Text = property.Area.ToString();
            TbPropertyRooms.Text = property.Rooms.ToString();
            TbPropertyFloor.Text = property.Floor.ToString();
            TbPropertyPrice.Text = property.Price.ToString();
            SelectComboItemByContent(CbPropertyType, property.PropertyType);
            SelectComboItemByContent(CbPropertyStatus, property.Status);
            SelectClientInCombo(CbPropertyOwner, property.OwnerID);
        }
        finally
        {
            _suppressFormFill--;
        }
    }

    private void ClearPropertyForm()
    {
        _suppressFormFill++;
        try
        {
            DgProperties.SelectedItem = null;
            TbPropertyAddress.Clear();
            TbPropertyArea.Clear();
            TbPropertyRooms.Clear();
            TbPropertyFloor.Clear();
            TbPropertyPrice.Clear();
            EnsureComboDefault(CbPropertyType);
            EnsureComboDefault(CbPropertyStatus);
            CbPropertyOwner.SelectedItem = null;
        }
        finally
        {
            _suppressFormFill--;
        }
    }

    private void FillDealForm(Deal deal)
    {
        _suppressFormFill++;
        try
        {
            TbDealAmount.Text = deal.Amount.ToString();
            DpDealDate.SelectedDate = deal.DealDate;
            SelectComboItemByContent(CbDealType, deal.DealType);
            SelectComboItemByContent(CbDealStatus, deal.Status);
            SelectPropertyInCombo(CbDealProperty, deal.PropertyID);
            SelectClientInCombo(CbDealClient, deal.ClientID);
        }
        finally
        {
            _suppressFormFill--;
        }
    }

    private void ClearDealForm()
    {
        _suppressFormFill++;
        try
        {
            DgDeals.SelectedItem = null;
            TbDealAmount.Clear();
            DpDealDate.SelectedDate = DateTime.Today;
            EnsureComboDefault(CbDealType);
            EnsureComboDefault(CbDealStatus);
            CbDealProperty.SelectedItem = null;
            CbDealClient.SelectedItem = null;
        }
        finally
        {
            _suppressFormFill--;
        }
    }

    private void FillUserForm(User user)
    {
        _suppressComboPersist++;
        _suppressFormFill++;
        try
        {
            TbSelectedUserLogin.Text = user.Login;
            ChbUserCanEdit.IsChecked = user.CanEdit;
            ChbUserIsActive.IsChecked = user.IsActive;
            SelectUserRoleCombo(user.Role);
        }
        finally
        {
            _suppressFormFill--;
            _suppressComboPersist--;
        }
    }

    private void ClearUserForm()
    {
        _suppressComboPersist++;
        _suppressFormFill++;
        try
        {
            DgUsers.SelectedItem = null;
            TbSelectedUserLogin.Text = "—";
            ChbUserCanEdit.IsChecked = false;
            ChbUserIsActive.IsChecked = false;
            EnsureComboDefault(CbUserRole);
        }
        finally
        {
            _suppressFormFill--;
            _suppressComboPersist--;
        }
    }

    private void ReselectClient(int clientId)
    {
        if (DgClients.ItemsSource is not IEnumerable<Client> clients)
        {
            return;
        }

        Client? match = clients.FirstOrDefault(c => c.ClientID == clientId);
        if (match is not null)
        {
            DgClients.SelectedItem = match;
        }
    }

    private void ReselectProperty(int propertyId)
    {
        if (DgProperties.ItemsSource is not IEnumerable<Property> properties)
        {
            return;
        }

        Property? match = properties.FirstOrDefault(p => p.PropertyID == propertyId);
        if (match is not null)
        {
            DgProperties.SelectedItem = match;
        }
    }

    private void ReselectDeal(int dealId)
    {
        if (DgDeals.ItemsSource is not IEnumerable<Deal> deals)
        {
            return;
        }

        Deal? match = deals.FirstOrDefault(d => d.DealID == dealId);
        if (match is not null)
        {
            DgDeals.SelectedItem = match;
        }
    }

    private void ReselectUser(int userId)
    {
        if (DgUsers.ItemsSource is not IEnumerable<User> users)
        {
            return;
        }

        User? match = users.FirstOrDefault(u => u.UserID == userId);
        if (match is not null)
        {
            DgUsers.SelectedItem = match;
        }
    }

    private static void SelectComboItemByContent(ComboBox comboBox, string value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            comboBox.SelectedItem = null;
            return;
        }

        foreach (object item in comboBox.Items)
        {
            if (item is ComboBoxItem comboItem && comboItem.Content is string text
                && string.Equals(text, value, StringComparison.OrdinalIgnoreCase))
            {
                comboBox.SelectedItem = comboItem;
                return;
            }
        }

        comboBox.Text = value;
    }

    private static void SelectClientInCombo(ComboBox comboBox, int clientId)
    {
        if (comboBox.ItemsSource is IEnumerable<Client> clients)
        {
            comboBox.SelectedItem = clients.FirstOrDefault(c => c.ClientID == clientId);
        }
    }

    private static void SelectPropertyInCombo(ComboBox comboBox, int propertyId)
    {
        if (comboBox.ItemsSource is IEnumerable<Property> properties)
        {
            comboBox.SelectedItem = properties.FirstOrDefault(p => p.PropertyID == propertyId);
        }
    }

    private void SelectUserRoleCombo(string role)
    {
        bool isAdmin = string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase);
        foreach (object item in CbUserRole.Items)
        {
            if (item is ComboBoxItem comboItem)
            {
                string? tag = comboItem.Tag?.ToString();
                if (isAdmin && string.Equals(tag, "Admin", StringComparison.OrdinalIgnoreCase))
                {
                    CbUserRole.SelectedItem = comboItem;
                    return;
                }

                if (!isAdmin && string.Equals(tag, "User", StringComparison.OrdinalIgnoreCase))
                {
                    CbUserRole.SelectedItem = comboItem;
                    return;
                }
            }
        }
    }

    private Property ReadProperty()
    {
        return new Property
        {
            Address = TbPropertyAddress.Text.Trim(),
            PropertyType = ReadComboText(CbPropertyType, "Тип объекта"),
            Area = ParseDouble(TbPropertyArea.Text, "Площадь"),
            Rooms = ParseInt(TbPropertyRooms.Text, "Комнаты"),
            Floor = ParseInt(TbPropertyFloor.Text, "Этаж"),
            Price = ParseDecimal(TbPropertyPrice.Text, "Цена"),
            Status = ReadComboText(CbPropertyStatus, "Статус"),
            OwnerID = ReadSelectedClientId(CbPropertyOwner, "Владелец")
        };
    }

    private Deal ReadDeal()
    {
        if (!DpDealDate.SelectedDate.HasValue)
        {
            throw new InvalidOperationException("Укажите дату сделки.");
        }

        return new Deal
        {
            PropertyID = ReadSelectedPropertyId(CbDealProperty, "Объект"),
            ClientID = ReadSelectedClientId(CbDealClient, "Клиент"),
            DealType = ReadComboText(CbDealType, "Тип сделки"),
            Amount = ParseDecimal(TbDealAmount.Text, "Сумма"),
            DealDate = DpDealDate.SelectedDate.Value,
            Status = ReadComboText(CbDealStatus, "Статус")
        };
    }

    private static void EnsureComboDefault(ComboBox comboBox)
    {
        if (comboBox.SelectedIndex < 0 && comboBox.Items.Count > 0)
        {
            comboBox.SelectedIndex = 0;
        }
    }

    private static string ReadOptionalComboText(ComboBox comboBox)
    {
        if (comboBox.SelectedItem is ComboBoxItem item && item.Content is string text)
        {
            return text == "(все)" ? string.Empty : text;
        }

        string typedText = comboBox.Text?.Trim() ?? string.Empty;
        return typedText == "(все)" ? string.Empty : typedText;
    }

    private static int ReadSelectedClientId(ComboBox comboBox, string fieldName)
    {
        if (comboBox.SelectedItem is Client client)
        {
            return client.ClientID;
        }

        throw new InvalidOperationException($"Выберите значение в поле '{fieldName}'.");
    }

    private static int ReadSelectedPropertyId(ComboBox comboBox, string fieldName)
    {
        if (comboBox.SelectedItem is Property property)
        {
            return property.PropertyID;
        }

        throw new InvalidOperationException($"Выберите значение в поле '{fieldName}'.");
    }

    private static string ReadComboText(ComboBox comboBox, string fieldName)
    {
        if (comboBox.SelectedItem is ComboBoxItem item && item.Content is string text)
        {
            return text;
        }

        string typedText = comboBox.Text?.Trim() ?? string.Empty;
        if (!string.IsNullOrWhiteSpace(typedText))
        {
            return typedText;
        }

        throw new InvalidOperationException($"Выберите значение в поле '{fieldName}'.");
    }

    private static int ParseInt(string value, string fieldName)
    {
        if (!int.TryParse(value, out int result))
        {
            throw new InvalidOperationException($"Поле '{fieldName}' должно быть целым числом.");
        }
        return result;
    }

    private static int? ParseNullableInt(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        return int.TryParse(value, out int result) ? result : null;
    }

    private static double ParseDouble(string value, string fieldName)
    {
        if (!double.TryParse(value, out double result))
        {
            throw new InvalidOperationException($"Поле '{fieldName}' должно быть числом.");
        }
        return result;
    }

    private static decimal ParseDecimal(string value, string fieldName)
    {
        if (!decimal.TryParse(value, out decimal result))
        {
            throw new InvalidOperationException($"Поле '{fieldName}' должно быть числом.");
        }
        return result;
    }

    private static decimal? ParseNullableDecimal(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        return decimal.TryParse(value, out decimal result) ? result : null;
    }

    private bool EnsureCanEditData()
    {
        if (CanEditData)
        {
            return true;
        }

        MessageBox.Show("У вас нет прав на редактирование данных.", "Доступ запрещен", MessageBoxButton.OK, MessageBoxImage.Warning);
        return false;
    }

    private bool EnsureIsAdmin()
    {
        if (IsAdmin)
        {
            return true;
        }

        MessageBox.Show("Раздел доступен только главному администратору.", "Доступ запрещен", MessageBoxButton.OK, MessageBoxImage.Warning);
        return false;
    }

    private static string ReadRoleValue(ComboBox comboBox)
    {
        if (comboBox.SelectedItem is ComboBoxItem item)
        {
            string? tag = item.Tag?.ToString();
            if (!string.IsNullOrWhiteSpace(tag))
            {
                return tag;
            }
        }

        return ReadComboText(comboBox, "Роль");
    }

    private static string GetRoleTitle(string? role) =>
        string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase) ? "Администратор" : "Пользователь";

    private void BtnLogout_OnClick(object sender, RoutedEventArgs e)
    {
        var login = new LoginWindow();
        login.Show();
        Close();
    }
}
