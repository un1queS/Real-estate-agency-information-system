﻿using System.Windows;
using System.Windows.Input;

namespace RentalMain2.UI;

public partial class LoginWindow : Window
{
    public LoginWindow()
    {
        InitializeComponent();
        TbLogin.Text = "admin";
        TbDbInfo.Text = string.IsNullOrWhiteSpace(App.DatabasePath) ? string.Empty : $"База данных: {App.DatabasePath}";
    }

    private void RegisterLink_OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        var register = new RegisterWindow { Owner = this };
        register.ShowDialog();
    }

    private async void BtnLogin_OnClick(object sender, RoutedEventArgs e)
    {
        try
        {
            if (App.Repository is null)
            {
                MessageBox.Show("Репозиторий БД не инициализирован.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string login = TbLogin.Text.Trim();
            string password = PbPassword.Password.Trim();

            var user = await App.Repository.AuthenticateAsync(login, password);
            if (user is null)
            {
                MessageBox.Show("Неверный логин или пароль.", "Вход", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!user.IsActive)
            {
                MessageBox.Show("Доступ в приложение не выдан администратором.", "Вход", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            App.CurrentUser = user;
            var main = new MainWindow();
            main.Show();
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка авторизации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnExit_OnClick(object sender, RoutedEventArgs e)
    {
        Application.Current.Shutdown();
    }
}
