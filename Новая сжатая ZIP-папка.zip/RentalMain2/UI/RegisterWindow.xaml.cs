using System.Windows;

namespace RentalMain2.UI;

public partial class RegisterWindow : Window
{
    public RegisterWindow()
    {
        InitializeComponent();
    }

    private async void BtnRegister_OnClick(object sender, RoutedEventArgs e)
    {
        try
        {
            if (App.Repository is null)
            {
                MessageBox.Show("Репозиторий БД не инициализирован.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            (bool success, string message) = await App.Repository.RegisterUserAsync(
                TbLogin.Text,
                PbPassword.Password,
                PbPasswordConfirm.Password);

            MessageBox.Show(message, success ? "Регистрация" : "Регистрация", MessageBoxButton.OK,
                success ? MessageBoxImage.Information : MessageBoxImage.Warning);

            if (success)
            {
                DialogResult = true;
                Close();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BtnBack_OnClick(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }
}
