﻿using System.Windows;
using RentalMain2.Data;
using RentalMain2.Services;

namespace RentalMain2;

public partial class App : Application
{
    public static RealEstateRepository? Repository { get; private set; }
    public static RentalMain2.Models.User? CurrentUser { get; set; }
    public static string? DatabasePath { get; private set; }

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        try
        {
            AppConfig config = AppConfig.Load();
            DatabasePath = config.DatabasePath;
            await AccessDbInitializer.EnsureDatabaseAsync(config.DatabasePath, config.CreateIfMissing);
            string connectionString = AccessDbInitializer.BuildConnectionString(config.DatabasePath);
            Repository = new RealEstateRepository(connectionString);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                $"Ошибка запуска приложения: {ex.Message}\nПроверьте установку Microsoft Access Database Engine.",
                "Ошибка",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            Shutdown();
        }
    }
}
