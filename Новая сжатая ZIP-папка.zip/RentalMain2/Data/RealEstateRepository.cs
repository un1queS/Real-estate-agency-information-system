﻿using System.Data;
using System.Data.OleDb;
using RentalMain2.Models;

namespace RentalMain2.Data;

public sealed class RealEstateRepository
{
    private readonly string _connectionString;
    private SchemaMode _schemaMode = SchemaMode.Unknown;
    private const string UsersTableRu = "Пользователи";
    private const string UserIdRu = "ID_Пользователя";
    private const string LoginRu = "Логин";
    private const string PasswordRu = "Пароль";
    private const string RoleRu = "Роль";
    private const string CanEditRu = "МожетРедактировать";
    private const string IsActiveRu = "ДоступРазрешен";

    private enum SchemaMode
    {
        Unknown = 0,
        Standard = 1,
        Russian = 2
    }

    public RealEstateRepository(string connectionString)
    {
        _connectionString = connectionString;
    }

    public async Task<User?> AuthenticateAsync(string login, string password)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        UserSchema userSchema = ResolveUserSchema(connection);
        if (userSchema == UserSchema.None)
        {
            return null;
        }

        string sql = userSchema == UserSchema.Russian
            ? $"SELECT [{UserIdRu}], [{LoginRu}], [{PasswordRu}], [{RoleRu}], [{CanEditRu}], [{IsActiveRu}] FROM [{UsersTableRu}] WHERE [{LoginRu}] = ? AND [{PasswordRu}] = ?"
            : "SELECT UserID, [Login], [Password], [Role], [CanEdit], [IsActive] FROM Users WHERE [Login] = ? AND [Password] = ?";

        using var command = new OleDbCommand(sql, connection);
        command.Parameters.AddWithValue("@login", login);
        command.Parameters.AddWithValue("@password", password);
        using var reader = await command.ExecuteReaderAsync();
        if (reader is null || !await reader.ReadAsync())
        {
            return null;
        }

        return new User
        {
            UserID = reader.GetInt32(0),
            Login = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
            Password = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
            Role = reader.IsDBNull(3) ? "User" : Convert.ToString(reader.GetValue(3)) ?? "User",
            CanEdit = !reader.IsDBNull(4) && Convert.ToBoolean(reader.GetValue(4)),
            IsActive = reader.IsDBNull(5) || Convert.ToBoolean(reader.GetValue(5))
        };
    }

    public async Task<(bool Success, string Message)> RegisterUserAsync(string login, string password, string confirmPassword)
    {
        login = login.Trim();
        password = password.Trim();
        confirmPassword = confirmPassword.Trim();

        if (string.IsNullOrWhiteSpace(login))
        {
            return (false, "Введите логин.");
        }

        if (string.IsNullOrWhiteSpace(password))
        {
            return (false, "Введите пароль.");
        }

        if (password != confirmPassword)
        {
            return (false, "Пароли не совпадают.");
        }

        if (login.Length < 3)
        {
            return (false, "Логин не короче 3 символов.");
        }

        if (password.Length < 3)
        {
            return (false, "Пароль не короче 3 символов.");
        }

        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        UserSchema userSchema = ResolveUserSchema(connection);
        if (userSchema == UserSchema.None)
        {
            return (false, "В базе данных нет таблицы пользователей. Регистрация недоступна для этой схемы.");
        }

        string dupSql = userSchema == UserSchema.Russian
            ? $"SELECT COUNT(*) FROM [{UsersTableRu}] WHERE [{LoginRu}] = ?"
            : "SELECT COUNT(*) FROM Users WHERE [Login] = ?";
        using (var dupCmd = new OleDbCommand(dupSql, connection))
        {
            dupCmd.Parameters.AddWithValue("@login", login);
            int existing = Convert.ToInt32(await dupCmd.ExecuteScalarAsync() ?? 0);
            if (existing > 0)
            {
                return (false, "Пользователь с таким логином уже существует.");
            }
        }

        string insertSql = userSchema == UserSchema.Russian
            ? $"INSERT INTO [{UsersTableRu}] ([{LoginRu}], [{PasswordRu}], [{RoleRu}], [{CanEditRu}], [{IsActiveRu}]) VALUES (?, ?, ?, ?, ?)"
            : "INSERT INTO Users ([Login], [Password], [Role], [CanEdit], [IsActive]) VALUES (?, ?, ?, ?, ?)";
        using var insertCmd = new OleDbCommand(insertSql, connection);
        insertCmd.Parameters.AddWithValue("@login", login);
        insertCmd.Parameters.AddWithValue("@password", password);
        insertCmd.Parameters.AddWithValue("@role", "User");
        insertCmd.Parameters.AddWithValue("@canEdit", false);
        insertCmd.Parameters.AddWithValue("@isActive", false);
        await insertCmd.ExecuteNonQueryAsync();
        return (true, "Регистрация выполнена. Ожидайте подтверждения доступа от администратора.");
    }

    public async Task<List<User>> GetAllUsersAsync()
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        var result = new List<User>();
        UserSchema userSchema = ResolveUserSchema(connection);
        if (userSchema == UserSchema.None)
        {
            return result;
        }

        string sql = userSchema == UserSchema.Russian
            ? $"SELECT [{UserIdRu}], [{LoginRu}], [{RoleRu}], [{CanEditRu}], [{IsActiveRu}] FROM [{UsersTableRu}] ORDER BY [{UserIdRu}]"
            : "SELECT UserID, [Login], [Role], [CanEdit], [IsActive] FROM Users ORDER BY UserID";
        using var command = new OleDbCommand(sql, connection);
        using var reader = await command.ExecuteReaderAsync();
        while (reader is not null && await reader.ReadAsync())
        {
            result.Add(new User
            {
                UserID = reader.GetInt32(0),
                Login = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                Password = string.Empty,
                Role = reader.IsDBNull(2) ? "User" : Convert.ToString(reader.GetValue(2)) ?? "User",
                CanEdit = !reader.IsDBNull(3) && Convert.ToBoolean(reader.GetValue(3)),
                IsActive = reader.IsDBNull(4) || Convert.ToBoolean(reader.GetValue(4))
            });
        }

        return result;
    }

    public async Task UpdateUserPermissionsAsync(int userId, string role, bool canEdit, bool isActive)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        UserSchema userSchema = ResolveUserSchema(connection);
        if (userSchema == UserSchema.None)
        {
            throw new InvalidOperationException("Таблица пользователей не найдена.");
        }

        string sql = userSchema == UserSchema.Russian
            ? $"UPDATE [{UsersTableRu}] SET [{RoleRu}] = ?, [{CanEditRu}] = ?, [{IsActiveRu}] = ? WHERE [{UserIdRu}] = ?"
            : "UPDATE Users SET [Role] = ?, [CanEdit] = ?, [IsActive] = ? WHERE UserID = ?";
        using var command = new OleDbCommand(sql, connection);
        command.Parameters.AddWithValue("@role", role);
        command.Parameters.AddWithValue("@canEdit", canEdit);
        command.Parameters.AddWithValue("@isActive", isActive);
        command.Parameters.AddWithValue("@id", userId);
        int affected = await command.ExecuteNonQueryAsync();
        if (affected == 0)
        {
            throw new InvalidOperationException("Пользователь не найден.");
        }
    }

    private enum UserSchema
    {
        None = 0,
        Russian = 1,
        English = 2
    }

    private static UserSchema ResolveUserSchema(OleDbConnection connection)
    {
        bool ruCompatible =
            TableExists(connection, UsersTableRu)
            && ColumnExists(connection, UsersTableRu, UserIdRu)
            && ColumnExists(connection, UsersTableRu, LoginRu)
            && ColumnExists(connection, UsersTableRu, PasswordRu)
            && ColumnExists(connection, UsersTableRu, RoleRu)
            && ColumnExists(connection, UsersTableRu, CanEditRu)
            && ColumnExists(connection, UsersTableRu, IsActiveRu);

        if (ruCompatible)
        {
            return UserSchema.Russian;
        }

        if (TableExists(connection, "Users"))
        {
            return UserSchema.English;
        }

        return UserSchema.None;
    }

    private static bool TableExists(OleDbConnection connection, string tableName)
    {
        DataTable schema = connection.GetSchema("Tables", new[] { null, null, tableName, "TABLE" });
        return schema.Rows.Count > 0;
    }

    private static bool ColumnExists(OleDbConnection connection, string tableName, string columnName)
    {
        DataTable schema = connection.GetSchema("Columns", new[] { null, null, tableName, columnName });
        return schema.Rows.Count > 0;
    }

    private static bool SupportsStandardDealsTable(OleDbConnection connection) =>
        TableExists(connection, "Deals")
        && ColumnExists(connection, "Deals", "DealType")
        && ColumnExists(connection, "Deals", "PropertyID");

    private const string RussianDealsSelectSql = @"
        SELECT s.ID_Сделки, s.Объект, s.Покупатель,
               IIF(Left(s.[Номер_Договора], 2) = 'АР', 'Аренда',
                   IIF(o.[Статус] IN ('Сдано', 'Арендовано'), 'Аренда', 'Продажа')) AS DealType,
               s.Цена_Продажи, s.Дата_Сделки, 'Завершена' AS DealStatus
        FROM (Сделки s
        LEFT JOIN Объекты_Недвижимости o ON s.Объект = o.ID_Объекта)
        ORDER BY s.Дата_Сделки DESC";

    private static string BuildDealContractNumber(string dealType) =>
        dealType == "Аренда"
            ? $"АР-{DateTime.Now:yyyyMMdd-HHmmss}"
            : $"ДКП-{DateTime.Now:yyyyMMdd-HHmmss}";

    private static string GetRussianPropertyStatusForDealType(string dealType) =>
        dealType == "Аренда" ? "Сдано" : "Продано";

    private static async Task UpdateRussianPropertyStatusForDealAsync(
        OleDbConnection connection,
        int propertyId,
        string dealType,
        OleDbTransaction? transaction = null)
    {
        string sql = "UPDATE [Объекты_Недвижимости] SET [Статус] = ? WHERE [ID_Объекта] = ?";
        using var command = transaction is null
            ? new OleDbCommand(sql, connection)
            : new OleDbCommand(sql, connection, transaction);
        command.Parameters.Add("@status", OleDbType.VarWChar, 50).Value = GetRussianPropertyStatusForDealType(dealType);
        command.Parameters.Add("@id", OleDbType.Integer).Value = propertyId;
        await command.ExecuteNonQueryAsync();
    }

    public async Task<DashboardSummary> GetDashboardSummaryAsync()
    {
        var clients = await GetClientsAsync();
        var properties = await GetPropertiesAsync();
        var activeProperties = await GetActivePropertiesAsync();
        var deals = await GetDealsAsync();

        DateTime monthStart = new(DateTime.Today.Year, DateTime.Today.Month, 1);
        DateTime monthEnd = monthStart.AddMonths(1);

        var dealsThisMonth = deals
            .Where(d => d.DealDate >= monthStart && d.DealDate < monthEnd)
            .ToList();

        int salesCount = deals.Count(d => string.Equals(d.DealType, "Продажа", StringComparison.OrdinalIgnoreCase));
        int rentCount = deals.Count(d => string.Equals(d.DealType, "Аренда", StringComparison.OrdinalIgnoreCase));

        return new DashboardSummary
        {
            ClientsCount = clients.Count,
            PropertiesCount = properties.Count,
            ActivePropertiesCount = activeProperties.Count,
            DealsCount = deals.Count,
            DealsThisMonthCount = dealsThisMonth.Count,
            DealsThisMonthAmount = dealsThisMonth.Sum(d => d.Amount),
            SalesDealsCount = salesCount,
            RentDealsCount = rentCount
        };
    }

    public async Task<List<Client>> GetClientsAsync()
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            List<Client> russian = await TryReadRussianClientsAsync(connection);
            if (russian.Count > 0)
            {
                return russian;
            }
        }

        List<Client> standardResult = await TryReadStandardClientsAsync(connection);
        if (standardResult.Count > 0)
        {
            return standardResult;
        }

        // Фолбэк: если "стандартная" выборка пустая или невалидна,
        // дополнительно пробуем русскую схему.
        List<Client> fallbackRussian = await TryReadRussianClientsAsync(connection);
        return fallbackRussian;
    }

    public async Task AddClientAsync(Client client)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            ParseFullName(client.FullName, out string lastName, out string firstName, out string middleName);
            const string sql = @"INSERT INTO Клиенты (Фамилия, Имя, Отчество, Тип, Телефон, Email, ПаспортныеДанные, АдресРегистрации)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            using var command = new OleDbCommand(sql, connection);
            command.Parameters.AddWithValue("@lastName", lastName);
            command.Parameters.AddWithValue("@firstName", firstName);
            command.Parameters.AddWithValue("@middleName", middleName);
            command.Parameters.AddWithValue("@type", client.ClientType);
            command.Parameters.AddWithValue("@phone", client.Phone);
            command.Parameters.AddWithValue("@email", client.Email);
            command.Parameters.AddWithValue("@passport", "");
            command.Parameters.AddWithValue("@address", "");
            await command.ExecuteNonQueryAsync();
            return;
        }

        const string standardSql = "INSERT INTO Clients (FullName, Phone, Email, ClientType) VALUES (?, ?, ?, ?)";
        using var standardCommand = new OleDbCommand(standardSql, connection);
        standardCommand.Parameters.AddWithValue("@fullName", client.FullName);
        standardCommand.Parameters.AddWithValue("@phone", client.Phone);
        standardCommand.Parameters.AddWithValue("@email", client.Email);
        standardCommand.Parameters.AddWithValue("@type", client.ClientType);
        await standardCommand.ExecuteNonQueryAsync();
    }

    public async Task UpdateClientAsync(Client client)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            ParseFullName(client.FullName, out string lastName, out string firstName, out string middleName);
            const string sql = @"UPDATE Клиенты SET Фамилия = ?, Имя = ?, Отчество = ?, Тип = ?, Телефон = ?, Email = ?
                                 WHERE ID_Клиента = ?";
            using var command = new OleDbCommand(sql, connection);
            command.Parameters.AddWithValue("@lastName", lastName);
            command.Parameters.AddWithValue("@firstName", firstName);
            command.Parameters.AddWithValue("@middleName", middleName);
            command.Parameters.AddWithValue("@type", client.ClientType);
            command.Parameters.AddWithValue("@phone", client.Phone);
            command.Parameters.AddWithValue("@email", client.Email);
            command.Parameters.AddWithValue("@id", client.ClientID);
            await command.ExecuteNonQueryAsync();
            return;
        }

        const string standardSql = "UPDATE Clients SET FullName = ?, Phone = ?, Email = ?, ClientType = ? WHERE ClientID = ?";
        using var standardCommand = new OleDbCommand(standardSql, connection);
        standardCommand.Parameters.AddWithValue("@fullName", client.FullName);
        standardCommand.Parameters.AddWithValue("@phone", client.Phone);
        standardCommand.Parameters.AddWithValue("@email", client.Email);
        standardCommand.Parameters.AddWithValue("@type", client.ClientType);
        standardCommand.Parameters.AddWithValue("@id", client.ClientID);
        await standardCommand.ExecuteNonQueryAsync();
    }

    public async Task DeleteClientAsync(int clientId)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            const string sql = "DELETE FROM Клиенты WHERE ID_Клиента = ?";
            using var command = new OleDbCommand(sql, connection);
            command.Parameters.AddWithValue("@id", clientId);
            await command.ExecuteNonQueryAsync();
            return;
        }

        const string standardSql = "DELETE FROM Clients WHERE ClientID = ?";
        using var standardCommand = new OleDbCommand(standardSql, connection);
        standardCommand.Parameters.AddWithValue("@id", clientId);
        await standardCommand.ExecuteNonQueryAsync();
    }

    public async Task<List<Property>> GetPropertiesAsync()
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            try
            {
                const string sql = @"SELECT ID_Объекта, Адрес, Тип_Объекта, Площадь, Комнат, Этаж, Цена, Статус, Владелец
                                 FROM Объекты_Недвижимости ORDER BY ID_Объекта";
                var russian = await ReadPropertiesAsync(connection, sql, null, russianMode: true);
                if (russian.Count > 0)
                {
                    return russian;
                }
            }
            catch
            {
                // Игнорируем и пробуем альтернативную схему.
            }
        }

        try
        {
            const string standardSql = @"SELECT PropertyID, [Address], PropertyType, Area, Rooms, Floor, Price, [Status], OwnerID 
                                     FROM Properties ORDER BY PropertyID";
            var standard = await ReadPropertiesAsync(connection, standardSql, null, russianMode: false);
            if (standard.Count > 0)
            {
                return standard;
            }
        }
        catch
        {
            // Игнорируем и пробуем русскую схему.
        }

        const string fallbackRuSql = @"SELECT ID_Объекта, Адрес, Тип_Объекта, Площадь, Комнат, Этаж, Цена, Статус, Владелец
                                       FROM Объекты_Недвижимости ORDER BY ID_Объекта";
        return await ReadPropertiesAsync(connection, fallbackRuSql, null, russianMode: true);
    }

    public async Task<List<Property>> GetActivePropertiesAsync()
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            try
            {
                const string sql = @"SELECT ID_Объекта, Адрес, Тип_Объекта, Площадь, Комнат, Этаж, Цена, Статус, Владелец
                                 FROM Объекты_Недвижимости WHERE Статус IN (?, ?) ORDER BY ID_Объекта";
                var russian = await ReadPropertiesAsync(connection, sql, cmd =>
                {
                    cmd.Parameters.AddWithValue("@s1", "Свободно");
                    cmd.Parameters.AddWithValue("@s2", "Активно");
                }, russianMode: true);
                if (russian.Count > 0)
                {
                    return russian;
                }
            }
            catch
            {
                // Игнорируем и пробуем альтернативную схему.
            }
        }

        try
        {
            const string standardSql = @"SELECT PropertyID, [Address], PropertyType, Area, Rooms, Floor, Price, [Status], OwnerID
                                     FROM Properties WHERE [Status] = ?";
            var standard = await ReadPropertiesAsync(connection, standardSql, cmd => cmd.Parameters.AddWithValue("@status", "Активно"), russianMode: false);
            if (standard.Count > 0)
            {
                return standard;
            }
        }
        catch
        {
            // Игнорируем и пробуем русскую схему.
        }

        const string fallbackRuSql = @"SELECT ID_Объекта, Адрес, Тип_Объекта, Площадь, Комнат, Этаж, Цена, Статус, Владелец
                                       FROM Объекты_Недвижимости WHERE Статус IN (?, ?) ORDER BY ID_Объекта";
        return await ReadPropertiesAsync(connection, fallbackRuSql, cmd =>
        {
            cmd.Parameters.AddWithValue("@s1", "Свободно");
            cmd.Parameters.AddWithValue("@s2", "Активно");
        }, russianMode: true);
    }

    public async Task<List<Property>> SearchPropertiesAsync(string? type, decimal? minPrice, decimal? maxPrice, int? rooms)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        bool russianMode = ResolveSchemaMode(connection) == SchemaMode.Russian;

        var filters = new List<string>();
        var values = new List<object>();

        if (!string.IsNullOrWhiteSpace(type))
        {
            filters.Add(russianMode ? "Тип_Объекта = ?" : "PropertyType = ?");
            values.Add(type);
        }
        if (minPrice.HasValue)
        {
            filters.Add(russianMode ? "Цена >= ?" : "Price >= ?");
            values.Add(minPrice.Value);
        }
        if (maxPrice.HasValue)
        {
            filters.Add(russianMode ? "Цена <= ?" : "Price <= ?");
            values.Add(maxPrice.Value);
        }
        if (rooms.HasValue)
        {
            filters.Add(russianMode ? "Комнат = ?" : "Rooms = ?");
            values.Add(rooms.Value);
        }

        string where = filters.Count > 0 ? $" WHERE {string.Join(" AND ", filters)}" : string.Empty;
        string sql = russianMode
            ? @"SELECT ID_Объекта, Адрес, Тип_Объекта, Площадь, Комнат, Этаж, Цена, Статус, Владелец
                FROM Объекты_Недвижимости" + where + " ORDER BY ID_Объекта"
            : @"SELECT PropertyID, [Address], PropertyType, Area, Rooms, Floor, Price, [Status], OwnerID
                FROM Properties" + where + " ORDER BY PropertyID";

        return await ReadPropertiesAsync(connection, sql, cmd =>
        {
            foreach (object value in values)
            {
                cmd.Parameters.AddWithValue("@p", value);
            }
        }, russianMode);
    }

    public async Task AddPropertyAsync(Property property)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            const string sql = @"INSERT INTO Объекты_Недвижимости (Владелец, Тип_Объекта, Статус, Адрес, Район, Комнат, Площадь, Этаж, [Кол-во_этажей], Цена, Описание, ДатаДобавления)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            using var command = new OleDbCommand(sql, connection);
            FillRussianPropertyParameters(command, property, includeId: false, includeExtraFields: true);
            await command.ExecuteNonQueryAsync();
            return;
        }

        const string standardSql = @"INSERT INTO Properties ([Address], PropertyType, Area, Rooms, Floor, Price, [Status], OwnerID)
                                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        using var standardCommand = new OleDbCommand(standardSql, connection);
        FillPropertyParameters(standardCommand, property, includeId: false);
        await standardCommand.ExecuteNonQueryAsync();
    }

    public async Task UpdatePropertyAsync(Property property)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            const string sql = @"UPDATE Объекты_Недвижимости
                                 SET Владелец = ?, Тип_Объекта = ?, Статус = ?, Адрес = ?, Комнат = ?, Площадь = ?, Этаж = ?, Цена = ?
                                 WHERE ID_Объекта = ?";
            using var command = new OleDbCommand(sql, connection);
            FillRussianPropertyParameters(command, property, includeId: true, includeExtraFields: false);
            await command.ExecuteNonQueryAsync();
            return;
        }

        const string standardSql = @"UPDATE Properties 
                                     SET [Address] = ?, PropertyType = ?, Area = ?, Rooms = ?, Floor = ?, Price = ?, [Status] = ?, OwnerID = ?
                                     WHERE PropertyID = ?";
        using var standardCommand = new OleDbCommand(standardSql, connection);
        FillPropertyParameters(standardCommand, property, includeId: true);
        await standardCommand.ExecuteNonQueryAsync();
    }

    public async Task DeletePropertyAsync(int propertyId)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            const string sql = "DELETE FROM Объекты_Недвижимости WHERE ID_Объекта = ?";
            using var command = new OleDbCommand(sql, connection);
            command.Parameters.AddWithValue("@id", propertyId);
            await command.ExecuteNonQueryAsync();
            return;
        }

        const string standardSql = "DELETE FROM Properties WHERE PropertyID = ?";
        using var standardCommand = new OleDbCommand(standardSql, connection);
        standardCommand.Parameters.AddWithValue("@id", propertyId);
        await standardCommand.ExecuteNonQueryAsync();
    }

    public async Task<List<Deal>> GetDealsAsync()
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        var result = new List<Deal>();

        if (SupportsStandardDealsTable(connection))
        {
            try
            {
                const string standardSql = "SELECT DealID, PropertyID, ClientID, DealType, Amount, DealDate, [Status] FROM Deals ORDER BY DealDate DESC";
                result.AddRange(await ReadDealsAsync(connection, standardSql, null));
            }
            catch
            {
                // Пробуем русскую схему ниже.
            }
        }

        if (ResolveSchemaMode(connection) == SchemaMode.Russian && TableExists(connection, "Сделки"))
        {
            try
            {
                var russian = await ReadDealsAsync(connection, RussianDealsSelectSql, null);
                if (result.Count == 0)
                {
                    return russian;
                }

                var existingIds = result.Select(d => d.DealID).ToHashSet();
                result.AddRange(russian.Where(d => !existingIds.Contains(d.DealID)));
            }
            catch
            {
                if (result.Count > 0)
                {
                    return result.OrderByDescending(d => d.DealDate).ToList();
                }
            }
        }

        if (result.Count > 0)
        {
            return result.OrderByDescending(d => d.DealDate).ToList();
        }

        if (SupportsStandardDealsTable(connection))
        {
            const string standardSql = "SELECT DealID, PropertyID, ClientID, DealType, Amount, DealDate, [Status] FROM Deals ORDER BY DealDate DESC";
            return await ReadDealsAsync(connection, standardSql, null);
        }

        return await ReadDealsAsync(connection, RussianDealsSelectSql, null);
    }

    private static async Task<List<Client>> TryReadRussianClientsAsync(OleDbConnection connection)
    {
        try
        {
            const string sql = @"SELECT ID_Клиента, Фамилия, Имя, Отчество, Телефон, Email, Тип
                                 FROM Клиенты ORDER BY ID_Клиента";
            var result = new List<Client>();
            using var command = new OleDbCommand(sql, connection);
            using var reader = await command.ExecuteReaderAsync();
            while (reader is not null && await reader.ReadAsync())
            {
                string lastName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1);
                string firstName = reader.IsDBNull(2) ? string.Empty : reader.GetString(2);
                string middleName = reader.IsDBNull(3) ? string.Empty : reader.GetString(3);
                string fullName = string.Join(" ", new[] { lastName, firstName, middleName }.Where(s => !string.IsNullOrWhiteSpace(s)));

                result.Add(new Client
                {
                    ClientID = Convert.ToInt32(reader.GetValue(0)),
                    FullName = fullName,
                    Phone = reader.IsDBNull(4) ? string.Empty : Convert.ToString(reader.GetValue(4)) ?? string.Empty,
                    Email = reader.IsDBNull(5) ? string.Empty : Convert.ToString(reader.GetValue(5)) ?? string.Empty,
                    ClientType = reader.IsDBNull(6) ? string.Empty : Convert.ToString(reader.GetValue(6)) ?? string.Empty
                });
            }

            return result;
        }
        catch
        {
            return new List<Client>();
        }
    }

    private static async Task<List<Client>> TryReadStandardClientsAsync(OleDbConnection connection)
    {
        try
        {
            const string standardSql = "SELECT ClientID, FullName, Phone, Email, ClientType FROM Clients ORDER BY ClientID";
            var standardResult = new List<Client>();
            using var command = new OleDbCommand(standardSql, connection);
            using var reader = await command.ExecuteReaderAsync();
            while (reader is not null && await reader.ReadAsync())
            {
                standardResult.Add(new Client
                {
                    ClientID = reader.GetInt32(0),
                    FullName = reader.GetString(1),
                    Phone = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                    Email = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                    ClientType = reader.IsDBNull(4) ? string.Empty : reader.GetString(4)
                });
            }

            return standardResult;
        }
        catch
        {
            return new List<Client>();
        }
    }

    public async Task AddDealAsync(Deal deal)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (SupportsStandardDealsTable(connection))
        {
            const string standardSql = "INSERT INTO Deals (PropertyID, ClientID, DealType, Amount, DealDate, [Status]) VALUES (?, ?, ?, ?, ?, ?)";
            using var standardCommand = new OleDbCommand(standardSql, connection);
            FillDealParameters(standardCommand, deal, includeId: false);
            await standardCommand.ExecuteNonQueryAsync();
            return;
        }

        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            const string sql = @"INSERT INTO Сделки (Номер_Договора, Дата_Сделки, Объект, Продавец, Покупатель, Риелтор, Цена_Продажи, Комиссия, ДатаРегистрации)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            using var command = new OleDbCommand(sql, connection);
            command.Parameters.Add("@num", OleDbType.VarWChar, 50).Value = BuildDealContractNumber(deal.DealType);
            command.Parameters.Add("@date", OleDbType.Date).Value = ToAccessDateParameter(deal.DealDate);
            command.Parameters.Add("@object", OleDbType.Integer).Value = deal.PropertyID;
            command.Parameters.Add("@seller", OleDbType.Integer).Value = deal.ClientID;
            command.Parameters.Add("@buyer", OleDbType.Integer).Value = deal.ClientID;
            command.Parameters.Add("@realtor", OleDbType.Integer).Value = 1;
            command.Parameters.Add("@amount", OleDbType.Currency).Value = deal.Amount;
            command.Parameters.Add("@commission", OleDbType.Currency).Value = Math.Round(deal.Amount * 0.05m, 2);
            command.Parameters.Add("@regDate", OleDbType.Date).Value = ToAccessDateParameter(DateTime.Now);
            await command.ExecuteNonQueryAsync();
            await UpdateRussianPropertyStatusForDealAsync(connection, deal.PropertyID, deal.DealType);
            return;
        }

        const string fallbackSql = "INSERT INTO Deals (PropertyID, ClientID, DealType, Amount, DealDate, [Status]) VALUES (?, ?, ?, ?, ?, ?)";
        using var fallbackCommand = new OleDbCommand(fallbackSql, connection);
        FillDealParameters(fallbackCommand, deal, includeId: false);
        await fallbackCommand.ExecuteNonQueryAsync();
    }

    public async Task UpdateDealAsync(Deal deal)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (SupportsStandardDealsTable(connection))
        {
            const string standardSql = @"UPDATE Deals SET PropertyID = ?, ClientID = ?, DealType = ?, Amount = ?, DealDate = ?, [Status] = ?
                                         WHERE DealID = ?";
            using var standardCommand = new OleDbCommand(standardSql, connection);
            FillDealParameters(standardCommand, deal, includeId: true);
            int affected = await standardCommand.ExecuteNonQueryAsync();
            if (affected > 0)
            {
                return;
            }
        }

        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            const string sql = @"UPDATE Сделки SET Номер_Договора = ?, Дата_Сделки = ?, Объект = ?, Покупатель = ?, Продавец = ?, Цена_Продажи = ?, Комиссия = ?
                                 WHERE ID_Сделки = ?";
            using var command = new OleDbCommand(sql, connection);
            command.Parameters.Add("@num", OleDbType.VarWChar, 50).Value = BuildDealContractNumber(deal.DealType);
            command.Parameters.Add("@date", OleDbType.Date).Value = ToAccessDateParameter(deal.DealDate);
            command.Parameters.Add("@object", OleDbType.Integer).Value = deal.PropertyID;
            command.Parameters.Add("@buyer", OleDbType.Integer).Value = deal.ClientID;
            command.Parameters.Add("@seller", OleDbType.Integer).Value = deal.ClientID;
            command.Parameters.Add("@amount", OleDbType.Currency).Value = deal.Amount;
            command.Parameters.Add("@commission", OleDbType.Currency).Value = Math.Round(deal.Amount * 0.05m, 2);
            command.Parameters.Add("@id", OleDbType.Integer).Value = deal.DealID;
            await command.ExecuteNonQueryAsync();
            await UpdateRussianPropertyStatusForDealAsync(connection, deal.PropertyID, deal.DealType);
            return;
        }

        const string fallbackSql = @"UPDATE Deals SET PropertyID = ?, ClientID = ?, DealType = ?, Amount = ?, DealDate = ?, [Status] = ?
                                     WHERE DealID = ?";
        using var fallbackCommand = new OleDbCommand(fallbackSql, connection);
        FillDealParameters(fallbackCommand, deal, includeId: true);
        await fallbackCommand.ExecuteNonQueryAsync();
    }

    public async Task DeleteDealAsync(int dealId)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (SupportsStandardDealsTable(connection))
        {
            const string standardSql = "DELETE FROM Deals WHERE DealID = ?";
            using var standardCommand = new OleDbCommand(standardSql, connection);
            standardCommand.Parameters.Add("@id", OleDbType.Integer).Value = dealId;
            int affected = await standardCommand.ExecuteNonQueryAsync();
            if (affected > 0)
            {
                return;
            }
        }

        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            const string sql = "DELETE FROM Сделки WHERE ID_Сделки = ?";
            using var command = new OleDbCommand(sql, connection);
            command.Parameters.Add("@id", OleDbType.Integer).Value = dealId;
            await command.ExecuteNonQueryAsync();
            return;
        }

        const string fallbackSql = "DELETE FROM Deals WHERE DealID = ?";
        using var fallbackCommand = new OleDbCommand(fallbackSql, connection);
        fallbackCommand.Parameters.Add("@id", OleDbType.Integer).Value = dealId;
        await fallbackCommand.ExecuteNonQueryAsync();
    }

    public async Task CreateCompletedDealAsync(int propertyId, int clientId, string dealType, decimal amount)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            using var transactionRu = connection.BeginTransaction();
            try
            {
                const string insertRu = @"INSERT INTO Сделки (Номер_Договора, Дата_Сделки, Объект, Продавец, Покупатель, Риелтор, Цена_Продажи, Комиссия, ДатаРегистрации)
                                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                using (var insertCmd = new OleDbCommand(insertRu, connection, transactionRu))
                {
                    insertCmd.Parameters.Add("@num", OleDbType.VarWChar, 50).Value = BuildDealContractNumber(dealType);
                    insertCmd.Parameters.Add("@date", OleDbType.Date).Value = DateTime.Now;
                    insertCmd.Parameters.Add("@object", OleDbType.Integer).Value = propertyId;
                    insertCmd.Parameters.Add("@seller", OleDbType.Integer).Value = clientId;
                    insertCmd.Parameters.Add("@buyer", OleDbType.Integer).Value = clientId;
                    insertCmd.Parameters.Add("@realtor", OleDbType.Integer).Value = 1;
                    insertCmd.Parameters.Add("@amount", OleDbType.Currency).Value = amount;
                    insertCmd.Parameters.Add("@commission", OleDbType.Currency).Value = Math.Round(amount * 0.05m, 2);
                    insertCmd.Parameters.Add("@regDate", OleDbType.Date).Value = DateTime.Now;
                    await insertCmd.ExecuteNonQueryAsync();
                }

                const string updateRu = "UPDATE Объекты_Недвижимости SET Статус = ? WHERE ID_Объекта = ?";
                using (var updateCmd = new OleDbCommand(updateRu, connection, transactionRu))
                {
                    string newStatus = dealType == "Аренда" ? "Сдано" : "Продано";
                    updateCmd.CommandText = "UPDATE [Объекты_Недвижимости] SET [Статус] = ? WHERE [ID_Объекта] = ?";
                    updateCmd.Parameters.Add("@status", OleDbType.VarWChar, 50).Value = newStatus;
                    updateCmd.Parameters.Add("@id", OleDbType.Integer).Value = propertyId;
                    await updateCmd.ExecuteNonQueryAsync();
                }

                transactionRu.Commit();
                return;
            }
            catch
            {
                transactionRu.Rollback();
                throw;
            }
        }

        using var transaction = connection.BeginTransaction();
        try
        {
            const string insertDealSql =
                "INSERT INTO Deals (PropertyID, ClientID, DealType, Amount, DealDate, [Status]) VALUES (?, ?, ?, ?, ?, ?)";
            using (var insertCmd = new OleDbCommand(insertDealSql, connection, transaction))
            {
                insertCmd.Parameters.AddWithValue("@propertyId", propertyId);
                insertCmd.Parameters.AddWithValue("@clientId", clientId);
                insertCmd.Parameters.AddWithValue("@dealType", dealType);
                insertCmd.Parameters.AddWithValue("@amount", amount);
                insertCmd.Parameters.AddWithValue("@date", DateTime.Now);
                insertCmd.Parameters.AddWithValue("@status", "Завершена");
                await insertCmd.ExecuteNonQueryAsync();
            }

            string newPropertyStatus = dealType == "Продажа" ? "Продано" : "Арендовано";
            const string updatePropertySql = "UPDATE Properties SET [Status] = ? WHERE PropertyID = ? AND [Status] = ?";
            using (var updateCmd = new OleDbCommand(updatePropertySql, connection, transaction))
            {
                updateCmd.Parameters.AddWithValue("@status", newPropertyStatus);
                updateCmd.Parameters.AddWithValue("@propertyId", propertyId);
                updateCmd.Parameters.AddWithValue("@activeStatus", "Активно");
                int affected = await updateCmd.ExecuteNonQueryAsync();
                if (affected == 0)
                {
                    throw new InvalidOperationException("Объект уже не активен. Оформление сделки отменено.");
                }
            }

            transaction.Commit();
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    public async Task<List<string>> GetDealsReportByPeriodAsync(DateTime startDate, DateTime endDate)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            const string sql = @"
                SELECT s.ID_Сделки, s.Дата_Сделки,
                       IIF(Left(s.[Номер_Договора], 2) = 'АР', 'Аренда',
                           IIF(o.[Статус] IN ('Сдано', 'Арендовано'), 'Аренда', 'Продажа')),
                       s.Цена_Продажи, 'Завершена',
                       (к.Фамилия + ' ' + к.Имя + ' ' + к.Отчество) AS Клиент, o.Адрес
                FROM (Сделки s
                INNER JOIN Клиенты к ON s.Покупатель = к.ID_Клиента)
                INNER JOIN Объекты_Недвижимости o ON s.Объект = o.ID_Объекта
                WHERE s.Дата_Сделки >= ? AND s.Дата_Сделки <= ?
                ORDER BY s.Дата_Сделки";

            return await ReadDealLinesAsync(connection, sql, cmd =>
            {
                cmd.Parameters.AddWithValue("@start", startDate.Date);
                cmd.Parameters.AddWithValue("@end", endDate.Date.AddDays(1).AddSeconds(-1));
            });
        }

        const string standardSql = @"
            SELECT d.DealID, d.DealDate, d.DealType, d.Amount, d.[Status], c.FullName, p.[Address]
            FROM (Deals d 
            INNER JOIN Clients c ON d.ClientID = c.ClientID)
            INNER JOIN Properties p ON d.PropertyID = p.PropertyID
            WHERE d.DealDate >= ? AND d.DealDate <= ?
            ORDER BY d.DealDate";

        return await ReadDealLinesAsync(connection, standardSql, cmd =>
        {
            cmd.Parameters.AddWithValue("@start", startDate.Date);
            cmd.Parameters.AddWithValue("@end", endDate.Date.AddDays(1).AddSeconds(-1));
        });
    }

    public async Task<List<string>> GetClientDealsReportAsync(int clientId)
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        if (ResolveSchemaMode(connection) == SchemaMode.Russian)
        {
            const string sql = @"
                SELECT s.ID_Сделки, s.Дата_Сделки,
                       IIF(Left(s.[Номер_Договора], 2) = 'АР', 'Аренда',
                           IIF(o.[Статус] IN ('Сдано', 'Арендовано'), 'Аренда', 'Продажа')),
                       s.Цена_Продажи, 'Завершена', o.Адрес, o.Тип_Объекта
                FROM Сделки s
                INNER JOIN Объекты_Недвижимости o ON s.Объект = o.ID_Объекта
                WHERE s.Покупатель = ? OR s.Продавец = ?
                ORDER BY s.Дата_Сделки DESC";
            return await ReadDealLinesAsync(connection, sql, cmd =>
            {
                cmd.Parameters.AddWithValue("@clientId1", clientId);
                cmd.Parameters.AddWithValue("@clientId2", clientId);
            });
        }

        const string standardSql = @"
            SELECT d.DealID, d.DealDate, d.DealType, d.Amount, d.[Status], p.[Address], p.PropertyType
            FROM Deals d
            INNER JOIN Properties p ON d.PropertyID = p.PropertyID
            WHERE d.ClientID = ?
            ORDER BY d.DealDate DESC";

        return await ReadDealLinesAsync(connection, standardSql, cmd => cmd.Parameters.AddWithValue("@clientId", clientId));
    }

    public async Task<List<string>> GetAllUserTableNamesAsync()
    {
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();

        var tableNames = connection
            .GetSchema("Tables")
            .Rows
            .Cast<DataRow>()
            .Where(row => string.Equals(Convert.ToString(row["TABLE_TYPE"]), "TABLE", StringComparison.OrdinalIgnoreCase))
            .Select(row => Convert.ToString(row["TABLE_NAME"]) ?? string.Empty)
            .Where(name => !string.IsNullOrWhiteSpace(name) && !name.StartsWith("MSys", StringComparison.OrdinalIgnoreCase))
            .OrderBy(name => name)
            .ToList();

        return tableNames;
    }

    public async Task<DataTable> GetTableDataAsync(string tableName)
    {
        var table = new DataTable();
        using var connection = new OleDbConnection(_connectionString);
        await connection.OpenAsync();
        using var command = new OleDbCommand($"SELECT * FROM [{tableName}]", connection);
        using var reader = await command.ExecuteReaderAsync();
        table.Load(reader!);
        return table;
    }

    private async Task<List<Property>> ReadPropertiesAsync(
        OleDbConnection connection,
        string sql,
        Action<OleDbCommand>? fillParams,
        bool russianMode)
    {
        var result = new List<Property>();
        using var command = new OleDbCommand(sql, connection);
        fillParams?.Invoke(command);
        using var reader = await command.ExecuteReaderAsync();
        while (reader is not null && await reader.ReadAsync())
        {
            result.Add(new Property
            {
                PropertyID = reader.GetInt32(0),
                Address = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                PropertyType = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                Area = reader.IsDBNull(3) ? 0 : Convert.ToDouble(reader.GetValue(3)),
                Rooms = reader.IsDBNull(4) ? 0 : Convert.ToInt32(reader.GetValue(4)),
                Floor = reader.IsDBNull(5) ? 0 : Convert.ToInt32(reader.GetValue(5)),
                Price = reader.IsDBNull(6) ? 0 : Convert.ToDecimal(reader.GetValue(6)),
                Status = reader.IsDBNull(7)
                    ? string.Empty
                    : russianMode
                        ? NormalizeUiPropertyStatus(Convert.ToString(reader.GetValue(7)) ?? string.Empty)
                        : reader.GetString(7),
                OwnerID = reader.IsDBNull(8) ? 0 : Convert.ToInt32(reader.GetValue(8))
            });
        }
        return result;
    }

    private async Task<List<Deal>> ReadDealsAsync(
        OleDbConnection connection,
        string sql,
        Action<OleDbCommand>? fillParams)
    {
        var result = new List<Deal>();
        using var command = new OleDbCommand(sql, connection);
        fillParams?.Invoke(command);
        using var reader = await command.ExecuteReaderAsync();
        while (reader is not null && await reader.ReadAsync())
        {
            result.Add(new Deal
            {
                DealID = reader.GetInt32(0),
                PropertyID = Convert.ToInt32(reader.GetValue(1)),
                ClientID = Convert.ToInt32(reader.GetValue(2)),
                DealType = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                Amount = reader.IsDBNull(4) ? 0 : Convert.ToDecimal(reader.GetValue(4)),
                DealDate = reader.IsDBNull(5) ? DateTime.MinValue : Convert.ToDateTime(reader.GetValue(5)),
                Status = reader.IsDBNull(6) ? string.Empty : reader.GetString(6)
            });
        }
        return result;
    }

    private async Task<List<string>> ReadDealLinesAsync(
        OleDbConnection connection,
        string sql,
        Action<OleDbCommand>? fillParams)
    {
        var rows = new List<string>();
        using var command = new OleDbCommand(sql, connection);
        fillParams?.Invoke(command);
        using var reader = await command.ExecuteReaderAsync();
        while (reader is not null && await reader.ReadAsync())
        {
            rows.Add(
                $"Сделка #{reader.GetInt32(0)} | Дата: {Convert.ToDateTime(reader.GetValue(1)):dd.MM.yyyy} | " +
                $"Тип: {reader.GetString(2)} | Сумма: {Convert.ToDecimal(reader.GetValue(3)):N2} | " +
                $"Статус: {reader.GetString(4)} | Клиент/Объект: {reader.GetString(5)} / {reader.GetString(6)}");
        }
        return rows;
    }

    private static void FillPropertyParameters(OleDbCommand command, Property property, bool includeId)
    {
        // ACE/Jet: AddWithValue часто ошибается с Decimal/Double → «Несоответствие типов данных...»
        command.Parameters.Add("@address", OleDbType.VarWChar, 255).Value = property.Address;
        command.Parameters.Add("@type", OleDbType.VarWChar, 50).Value = property.PropertyType;
        command.Parameters.Add("@area", OleDbType.Double).Value = property.Area;
        command.Parameters.Add("@rooms", OleDbType.Integer).Value = property.Rooms;
        command.Parameters.Add("@floor", OleDbType.Integer).Value = property.Floor;
        command.Parameters.Add("@price", OleDbType.Currency).Value = property.Price;
        command.Parameters.Add("@status", OleDbType.VarWChar, 50).Value = property.Status;
        command.Parameters.Add("@ownerId", OleDbType.Integer).Value = property.OwnerID;
        if (includeId)
        {
            command.Parameters.Add("@id", OleDbType.Integer).Value = property.PropertyID;
        }
    }

    private static void FillRussianPropertyParameters(
        OleDbCommand command,
        Property property,
        bool includeId,
        bool includeExtraFields)
    {
        command.Parameters.Add("@owner", OleDbType.Integer).Value = property.OwnerID;
        command.Parameters.Add("@type", OleDbType.VarWChar, 100).Value = property.PropertyType;
        command.Parameters.Add("@status", OleDbType.VarWChar, 50).Value = NormalizeRussianPropertyStatus(property.Status);
        command.Parameters.Add("@address", OleDbType.VarWChar, 255).Value = property.Address;
        if (includeExtraFields)
        {
            command.Parameters.Add("@district", OleDbType.VarWChar, 100).Value = string.Empty;
        }

        command.Parameters.Add("@rooms", OleDbType.Integer).Value = property.Rooms;
        command.Parameters.Add("@area", OleDbType.Double).Value = property.Area;
        command.Parameters.Add("@floor", OleDbType.Integer).Value = property.Floor;
        if (includeExtraFields)
        {
            command.Parameters.Add("@floors", OleDbType.Integer).Value = Math.Max(property.Floor, 1);
        }

        command.Parameters.Add("@price", OleDbType.Currency).Value = property.Price;
        if (includeExtraFields)
        {
            command.Parameters.Add("@description", OleDbType.VarWChar, 255).Value = string.Empty;
            command.Parameters.Add("@date", OleDbType.Date).Value = ToAccessDateParameter(DateTime.Now);
        }

        if (includeId)
        {
            command.Parameters.Add("@id", OleDbType.Integer).Value = property.PropertyID;
        }
    }

    private static DateTime ToAccessDateParameter(DateTime value)
    {
        DateTime d = value.Date;
        return d.Kind == DateTimeKind.Unspecified
            ? d
            : DateTime.SpecifyKind(d, DateTimeKind.Unspecified);
    }

    private static void FillDealParameters(OleDbCommand command, Deal deal, bool includeId)
    {
        // ACE/Jet: AddWithValue часто ошибается с Decimal/Date → "Несоответствие типов данных..."
        command.Parameters.Add("@propertyId", OleDbType.Integer).Value = deal.PropertyID;
        command.Parameters.Add("@clientId", OleDbType.Integer).Value = deal.ClientID;
        command.Parameters.Add("@type", OleDbType.VarWChar, 50).Value = deal.DealType;

        var amountParam = new OleDbParameter("@amount", OleDbType.Decimal)
        {
            Precision = 19,
            Scale = 4,
            Value = decimal.Round(deal.Amount, 4, MidpointRounding.AwayFromZero)
        };
        command.Parameters.Add(amountParam);

        command.Parameters.Add("@date", OleDbType.Date).Value = ToAccessDateParameter(deal.DealDate);
        command.Parameters.Add("@status", OleDbType.VarWChar, 50).Value = deal.Status;
        if (includeId)
        {
            command.Parameters.Add("@id", OleDbType.Integer).Value = deal.DealID;
        }
    }

    private SchemaMode ResolveSchemaMode(OleDbConnection connection)
    {
        if (_schemaMode != SchemaMode.Unknown)
        {
            return _schemaMode;
        }

        var tableNames = connection
            .GetSchema("Tables")
            .Rows
            .Cast<System.Data.DataRow>()
            .Where(row => string.Equals(Convert.ToString(row["TABLE_TYPE"]), "TABLE", StringComparison.OrdinalIgnoreCase))
            .Select(row => Convert.ToString(row["TABLE_NAME"]) ?? string.Empty)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        _schemaMode = tableNames.Contains("Клиенты")
                      && tableNames.Contains("Объекты_Недвижимости")
                      && tableNames.Contains("Сделки")
            ? SchemaMode.Russian
            : SchemaMode.Standard;

        return _schemaMode;
    }

    private static void ParseFullName(string fullName, out string lastName, out string firstName, out string middleName)
    {
        string[] parts = fullName
            .Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        lastName = parts.Length > 0 ? parts[0] : string.Empty;
        firstName = parts.Length > 1 ? parts[1] : string.Empty;
        middleName = parts.Length > 2 ? parts[2] : string.Empty;
    }

    private static string NormalizeUiPropertyStatus(string status) => status switch
    {
        "Свободно" => "Активно",
        "Сдано" => "Арендовано",
        _ => status
    };

    private static string NormalizeRussianPropertyStatus(string status) => status switch
    {
        "Активно" => "Свободно",
        "Арендовано" => "Сдано",
        _ => status
    };
}
