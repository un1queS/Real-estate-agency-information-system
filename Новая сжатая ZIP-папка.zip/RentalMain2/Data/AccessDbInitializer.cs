﻿using System.Data.OleDb;
using System.IO;
using System.Data;
using System.Runtime.InteropServices;
using System.Threading;

namespace RentalMain2.Data;

public static class AccessDbInitializer
{
    private const string UsersTableNameRu = "Пользователи";
    private const string UsersTableNameEn = "Users";

    private const string UserIdColRu = "ID_Пользователя";
    private const string LoginColRu = "Логин";
    private const string PasswordColRu = "Пароль";
    private const string RoleColRu = "Роль";
    private const string CanEditColRu = "МожетРедактировать";
    private const string IsActiveColRu = "ДоступРазрешен";

    private const string UsersTableDdl = @"CREATE TABLE Users (
                UserID COUNTER PRIMARY KEY,
                [Login] TEXT(100) NOT NULL,
                [Password] TEXT(100) NOT NULL,
                [Role] TEXT(20) NOT NULL,
                [CanEdit] YESNO NOT NULL,
                [IsActive] YESNO NOT NULL
            )";
    private const string UsersTableDdlRu = @"CREATE TABLE [Пользователи] (
                [ID_Пользователя] COUNTER PRIMARY KEY,
                [Логин] TEXT(100) NOT NULL,
                [Пароль] TEXT(100) NOT NULL,
                [Роль] TEXT(20) NOT NULL,
                [МожетРедактировать] YESNO NOT NULL,
                [ДоступРазрешен] YESNO NOT NULL
            )";

    public static async Task EnsureDatabaseAsync(string databasePath, bool createIfMissing = true)
    {
        bool isNewDatabase = false;
        if (!File.Exists(databasePath))
        {
            if (!createIfMissing)
            {
                throw new FileNotFoundException(
                    $"Файл базы данных не найден: {databasePath}. " +
                    "Положите готовый файл .accdb в эту папку (или исправьте имя в appsettings.json). " +
                    "Если нужна автоматическая пустая база, установите \"CreateIfMissing\": true.",
                    databasePath);
            }

            string? directory = Path.GetDirectoryName(databasePath);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }

            await CreateAccessFileAsync(databasePath);
            isNewDatabase = true;
        }

        string connectionString = BuildConnectionString(databasePath);
        if (isNewDatabase)
        {
            await EnsureSchemaAsync(connectionString);
        }
        else
        {
            // Для любой существующей БД гарантируем таблицу пользователей приложения.
            await EnsureUsersTableAsync(connectionString);
        }
    }

    public static string BuildConnectionString(string databasePath) =>
        $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={FormatOleDbFilePath(databasePath)};Persist Security Info=False;";

    /// <summary>
    /// Путь для OLE DB: в кавычках, внутренние кавычки удваиваются (пробелы, кириллица в имени файла).
    /// </summary>
    private static string FormatOleDbFilePath(string filePath)
    {
        string escaped = filePath.Replace("\"", "\"\"");
        return $"\"{escaped}\"";
    }

    private static Task CreateAccessFileAsync(string databasePath)
    {
        return Task.Run(() =>
        {
            // ADOX.Catalog.Create часто падает на путях с кириллицей/пробелами. Создаём во временном ASCII-пути и переносим.
            string tempFile = Path.Combine(Path.GetTempPath(), $"rentalmain2_new_{Guid.NewGuid():N}.accdb");
            try
            {
                CreateAccessFileAtPath(tempFile);

                MoveTempDatabaseToDestinationWithRetry(tempFile, databasePath);
            }
            catch (Exception ex)
            {
                try
                {
                    if (File.Exists(tempFile))
                    {
                        File.Delete(tempFile);
                    }
                }
                catch
                {
                    // Игнорируем.
                }

                throw new Exception($"Ошибка создания файла БД '{databasePath}': {ex.Message}", ex);
            }
        });
    }

    private static void CreateAccessFileAtPath(string databasePath)
    {
        // Создаем файл Access через COM-объект ADOX Catalog.
        Type? catalogType = Type.GetTypeFromProgID("ADOX.Catalog");
        if (catalogType is null)
        {
            throw new InvalidOperationException("ADOX.Catalog не найден. Убедитесь, что установлен Microsoft Access Database Engine.");
        }

        object catalogObj = Activator.CreateInstance(catalogType)
            ?? throw new InvalidOperationException("Не удалось создать ADOX.Catalog.");

        try
        {
            dynamic catalog = catalogObj;
            // Для .accdb не задаём Jet OLEDB:Engine Type=5 (формат Jet 4) — иначе провайдер может отвергнуть строку подключения.
            string quoted = FormatOleDbFilePath(databasePath);
            string createConnection = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={quoted};";
            catalog.Create(createConnection);
        }
        finally
        {
            ReleaseAdoxCatalog(catalogObj);
            // ACE может отпустить дескриптор файла не сразу после Release — даём GC и короткую паузу.
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            Thread.Sleep(100);
        }
    }

    /// <summary>
    /// Закрывает соединение ADOX и освобождает RCW — иначе временный .accdb остаётся заблокированным для File.Move.
    /// </summary>
    private static void ReleaseAdoxCatalog(object catalogObj)
    {
        try
        {
            dynamic catalog = catalogObj;
            try
            {
                object? active = catalog.ActiveConnection;
                if (active is not null)
                {
                    try
                    {
                        dynamic ac = active;
                        ac.Close();
                    }
                    catch
                    {
                        // Игнорируем.
                    }

                    try
                    {
                        Marshal.FinalReleaseComObject(active);
                    }
                    catch
                    {
                        // Игнорируем.
                    }
                }
            }
            catch
            {
                // Нет ActiveConnection — нормально для части версий.
            }

            try
            {
                catalog.ActiveConnection = null;
            }
            catch
            {
                // Игнорируем.
            }
        }
        catch
        {
            // Игнорируем.
        }

        try
        {
            Marshal.FinalReleaseComObject(catalogObj);
        }
        catch
        {
            // Игнорируем.
        }
    }

    private static void MoveTempDatabaseToDestinationWithRetry(string tempFile, string destinationPath)
    {
        const int maxAttempts = 40;
        const int delayMs = 75;

        for (int attempt = 0; attempt < maxAttempts; attempt++)
        {
            try
            {
                if (File.Exists(destinationPath))
                {
                    File.Delete(destinationPath);
                }

                File.Move(tempFile, destinationPath);
                return;
            }
            catch (Exception ex) when (attempt < maxAttempts - 1 && ex is IOException or UnauthorizedAccessException)
            {
                Thread.Sleep(delayMs);
            }
        }
    }

    private static async Task EnsureSchemaAsync(string connectionString)
    {
        var tables = new (string Name, string Sql)[]
        {
            ("Clients", @"CREATE TABLE Clients (
                ClientID COUNTER PRIMARY KEY,
                FullName TEXT(255) NOT NULL,
                Phone TEXT(50),
                Email TEXT(255),
                ClientType TEXT(50) NOT NULL
            )"),
            ("Properties", @"CREATE TABLE Properties (
                PropertyID COUNTER PRIMARY KEY,
                [Address] TEXT(255) NOT NULL,
                PropertyType TEXT(50) NOT NULL,
                Area DOUBLE,
                Rooms INTEGER,
                Floor INTEGER,
                Price CURRENCY,
                [Status] TEXT(50) NOT NULL,
                OwnerID INTEGER NOT NULL
            )"),
            ("Deals", @"CREATE TABLE Deals (
                DealID COUNTER PRIMARY KEY,
                PropertyID INTEGER NOT NULL,
                ClientID INTEGER NOT NULL,
                DealType TEXT(50) NOT NULL,
                Amount CURRENCY,
                DealDate DATETIME,
                [Status] TEXT(50) NOT NULL
            )"),
            (UsersTableNameRu, UsersTableDdlRu)
        };

        using var connection = new OleDbConnection(connectionString);
        await connection.OpenAsync();

        foreach ((string tableName, string ddl) in tables)
        {
            // Проверяем существование таблицы через метаданные Access,
            // чтобы не зависеть от языка текста ошибки драйвера.
            if (TableExists(connection, tableName))
            {
                continue;
            }

            using var command = new OleDbCommand(ddl, connection);
            await command.ExecuteNonQueryAsync();
        }

        await EnsureUsersStorageAsync(connection);

        // Заполняем демонстрационными данными только для новой созданной БД приложения.
        await SeedDemoDataAsync(connection);
    }

    private static async Task EnsureUsersTableAsync(string connectionString)
    {
        using var connection = new OleDbConnection(connectionString);
        await connection.OpenAsync();
        await EnsureUsersStorageAsync(connection);
    }

    private static async Task EnsureUsersStorageAsync(OleDbConnection connection)
    {
        bool hasRu = TableExists(connection, UsersTableNameRu);
        bool hasEn = TableExists(connection, UsersTableNameEn);

        // Для новых БД создаем "Пользователи" в ожидаемой схеме приложения.
        if (!hasRu && !hasEn)
        {
            using var createRu = new OleDbCommand(UsersTableDdlRu, connection);
            await createRu.ExecuteNonQueryAsync();
            hasRu = true;
        }

        // В существующих учебных БД таблица "Пользователи" может иметь обязательные поля
        // (например, ID_Сотрудника), из-за чего вставка стандартного admin падает.
        // В таком случае работаем через таблицу Users, если она есть.
        bool ruCompatible = hasRu && IsCompatibleRuUsersTable(connection);

        if (ruCompatible)
        {
            await EnsureUsersColumnsRuAsync(connection);
            await MigrateEnglishUsersAsync(connection);
            await EnsureBuiltInAdminAsync(connection);
            return;
        }

        if (!hasEn)
        {
            using var createEn = new OleDbCommand(UsersTableDdl, connection);
            await createEn.ExecuteNonQueryAsync();
            hasEn = true;
        }

        if (hasEn)
        {
            await EnsureUsersColumnsEnAsync(connection);
            await EnsureBuiltInAdminEnAsync(connection);
        }
    }

    private static async Task EnsureUsersColumnsRuAsync(OleDbConnection connection)
    {
        await AddColumnIfMissingAsync(connection, UsersTableNameRu, RoleColRu, "TEXT(20)");
        await AddColumnIfMissingAsync(connection, UsersTableNameRu, CanEditColRu, "YESNO");
        await AddColumnIfMissingAsync(connection, UsersTableNameRu, IsActiveColRu, "YESNO");

        using (var updateRole = new OleDbCommand($"UPDATE [{UsersTableNameRu}] SET [{RoleColRu}] = 'User' WHERE [{RoleColRu}] IS NULL OR [{RoleColRu}] = ''", connection))
        {
            await updateRole.ExecuteNonQueryAsync();
        }

        using (var updateCanEdit = new OleDbCommand($"UPDATE [{UsersTableNameRu}] SET [{CanEditColRu}] = False WHERE [{CanEditColRu}] IS NULL", connection))
        {
            await updateCanEdit.ExecuteNonQueryAsync();
        }

        using (var updateIsActive = new OleDbCommand($"UPDATE [{UsersTableNameRu}] SET [{IsActiveColRu}] = True WHERE [{IsActiveColRu}] IS NULL", connection))
        {
            await updateIsActive.ExecuteNonQueryAsync();
        }
    }

    private static async Task AddColumnIfMissingAsync(OleDbConnection connection, string tableName, string columnName, string columnType)
    {
        if (ColumnExists(connection, tableName, columnName))
        {
            return;
        }

        using var command = new OleDbCommand($"ALTER TABLE [{tableName}] ADD COLUMN [{columnName}] {columnType}", connection);
        await command.ExecuteNonQueryAsync();
    }

    private static async Task EnsureUsersColumnsEnAsync(OleDbConnection connection)
    {
        await AddColumnIfMissingAsync(connection, UsersTableNameEn, "Role", "TEXT(20)");
        await AddColumnIfMissingAsync(connection, UsersTableNameEn, "CanEdit", "YESNO");
        await AddColumnIfMissingAsync(connection, UsersTableNameEn, "IsActive", "YESNO");

        using (var updateRole = new OleDbCommand("UPDATE [Users] SET [Role] = 'User' WHERE [Role] IS NULL OR [Role] = ''", connection))
        {
            await updateRole.ExecuteNonQueryAsync();
        }

        using (var updateCanEdit = new OleDbCommand("UPDATE [Users] SET [CanEdit] = False WHERE [CanEdit] IS NULL", connection))
        {
            await updateCanEdit.ExecuteNonQueryAsync();
        }

        using (var updateIsActive = new OleDbCommand("UPDATE [Users] SET [IsActive] = True WHERE [IsActive] IS NULL", connection))
        {
            await updateIsActive.ExecuteNonQueryAsync();
        }
    }

    private static async Task MigrateEnglishUsersAsync(OleDbConnection connection)
    {
        if (!TableExists(connection, UsersTableNameEn))
        {
            return;
        }

        const string readSql = "SELECT [Login], [Password], [Role], [CanEdit], [IsActive] FROM [Users]";
        using var readCmd = new OleDbCommand(readSql, connection);
        using var reader = await readCmd.ExecuteReaderAsync();
        while (reader is not null && await reader.ReadAsync())
        {
            string login = reader.IsDBNull(0) ? string.Empty : Convert.ToString(reader.GetValue(0)) ?? string.Empty;
            if (string.IsNullOrWhiteSpace(login))
            {
                continue;
            }

            bool exists;
            using (var existsCmd = new OleDbCommand($"SELECT COUNT(*) FROM [{UsersTableNameRu}] WHERE [{LoginColRu}] = ?", connection))
            {
                existsCmd.Parameters.AddWithValue("@login", login);
                exists = Convert.ToInt32(await existsCmd.ExecuteScalarAsync()) > 0;
            }

            if (exists)
            {
                continue;
            }

            using var insertCmd = new OleDbCommand(
                $"INSERT INTO [{UsersTableNameRu}] ([{LoginColRu}], [{PasswordColRu}], [{RoleColRu}], [{CanEditColRu}], [{IsActiveColRu}]) VALUES (?, ?, ?, ?, ?)",
                connection);
            insertCmd.Parameters.AddWithValue("@login", login);
            insertCmd.Parameters.AddWithValue("@password", reader.IsDBNull(1) ? string.Empty : Convert.ToString(reader.GetValue(1)) ?? string.Empty);
            insertCmd.Parameters.AddWithValue("@role", reader.IsDBNull(2) ? "User" : Convert.ToString(reader.GetValue(2)) ?? "User");
            insertCmd.Parameters.AddWithValue("@canEdit", !reader.IsDBNull(3) && Convert.ToBoolean(reader.GetValue(3)));
            insertCmd.Parameters.AddWithValue("@isActive", reader.IsDBNull(4) || Convert.ToBoolean(reader.GetValue(4)));
            await insertCmd.ExecuteNonQueryAsync();
        }
    }

    private static bool TableExists(OleDbConnection connection, string tableName)
    {
        DataTable schema = connection.GetSchema(
            "Tables",
            new[] { null, null, tableName, "TABLE" });

        return schema.Rows.Count > 0;
    }

    private static bool ColumnExists(OleDbConnection connection, string tableName, string columnName)
    {
        DataTable schema = connection.GetSchema(
            "Columns",
            new[] { null, null, tableName, columnName });

        return schema.Rows.Count > 0;
    }

    /// <summary>
    /// Всегда обеспечивает учётную запись admin с ролью Admin (даже если в таблице уже есть другие пользователи).
    /// </summary>
    private static async Task EnsureBuiltInAdminAsync(OleDbConnection connection)
    {
        string countAllSql = $"SELECT COUNT(*) FROM [{UsersTableNameRu}]";
        using var countAllCmd = new OleDbCommand(countAllSql, connection);
        int total = Convert.ToInt32(await countAllCmd.ExecuteScalarAsync());

        if (total == 0)
        {
            await InsertBuiltInAdminAsync(connection);
            return;
        }

        string countAdminLoginSql = $"SELECT COUNT(*) FROM [{UsersTableNameRu}] WHERE [{LoginColRu}] = ?";
        using var countLoginCmd = new OleDbCommand(countAdminLoginSql, connection);
        countLoginCmd.Parameters.AddWithValue("@login", "admin");
        int adminLoginCount = Convert.ToInt32(await countLoginCmd.ExecuteScalarAsync());

        if (adminLoginCount > 0)
        {
            string updateSql = $"UPDATE [{UsersTableNameRu}] SET [{RoleColRu}] = ?, [{CanEditColRu}] = ?, [{IsActiveColRu}] = ? WHERE [{LoginColRu}] = ?";
            using var updateCmd = new OleDbCommand(updateSql, connection);
            updateCmd.Parameters.AddWithValue("@role", "Admin");
            updateCmd.Parameters.AddWithValue("@canEdit", true);
            updateCmd.Parameters.AddWithValue("@isActive", true);
            updateCmd.Parameters.AddWithValue("@login", "admin");
            await updateCmd.ExecuteNonQueryAsync();
            return;
        }

        await InsertBuiltInAdminAsync(connection);
    }

    private static async Task InsertBuiltInAdminAsync(OleDbConnection connection)
    {
        string insertAdminSql = $"INSERT INTO [{UsersTableNameRu}] ([{LoginColRu}], [{PasswordColRu}], [{RoleColRu}], [{CanEditColRu}], [{IsActiveColRu}]) VALUES (?, ?, ?, ?, ?)";
        using var insertAdminCmd = new OleDbCommand(insertAdminSql, connection);
        insertAdminCmd.Parameters.AddWithValue("@login", "admin");
        insertAdminCmd.Parameters.AddWithValue("@password", "admin123");
        insertAdminCmd.Parameters.AddWithValue("@role", "Admin");
        insertAdminCmd.Parameters.AddWithValue("@canEdit", true);
        insertAdminCmd.Parameters.AddWithValue("@isActive", true);
        await insertAdminCmd.ExecuteNonQueryAsync();
    }

    private static async Task EnsureBuiltInAdminEnAsync(OleDbConnection connection)
    {
        using (var countCmd = new OleDbCommand("SELECT COUNT(*) FROM [Users] WHERE [Login] = ?", connection))
        {
            countCmd.Parameters.AddWithValue("@login", "admin");
            int adminCount = Convert.ToInt32(await countCmd.ExecuteScalarAsync());
            if (adminCount > 0)
            {
                using var updateCmd = new OleDbCommand("UPDATE [Users] SET [Role] = ?, [CanEdit] = ?, [IsActive] = ? WHERE [Login] = ?", connection);
                updateCmd.Parameters.AddWithValue("@role", "Admin");
                updateCmd.Parameters.AddWithValue("@canEdit", true);
                updateCmd.Parameters.AddWithValue("@isActive", true);
                updateCmd.Parameters.AddWithValue("@login", "admin");
                await updateCmd.ExecuteNonQueryAsync();
                return;
            }
        }

        using var insertCmd = new OleDbCommand(
            "INSERT INTO [Users] ([Login], [Password], [Role], [CanEdit], [IsActive]) VALUES (?, ?, ?, ?, ?)",
            connection);
        insertCmd.Parameters.AddWithValue("@login", "admin");
        insertCmd.Parameters.AddWithValue("@password", "admin123");
        insertCmd.Parameters.AddWithValue("@role", "Admin");
        insertCmd.Parameters.AddWithValue("@canEdit", true);
        insertCmd.Parameters.AddWithValue("@isActive", true);
        await insertCmd.ExecuteNonQueryAsync();
    }

    private static bool IsCompatibleRuUsersTable(OleDbConnection connection) =>
        ColumnExists(connection, UsersTableNameRu, LoginColRu)
        && ColumnExists(connection, UsersTableNameRu, PasswordColRu)
        && ColumnExists(connection, UsersTableNameRu, RoleColRu)
        && ColumnExists(connection, UsersTableNameRu, CanEditColRu)
        && ColumnExists(connection, UsersTableNameRu, IsActiveColRu);

    private static async Task SeedDemoDataAsync(OleDbConnection connection)
    {
        // Если уже есть клиенты, считаем, что база заполнена реальными данными.
        using (var checkCmd = new OleDbCommand("SELECT COUNT(*) FROM Clients", connection))
        {
            try
            {
                int count = Convert.ToInt32(await checkCmd.ExecuteScalarAsync());
                if (count > 0)
                {
                    return;
                }
            }
            catch
            {
                // Таблицы нет или другая схема — выходим без демо-данных.
                return;
            }
        }

        // Клиенты
        using (var insertClient = new OleDbCommand(
                   "INSERT INTO Clients (FullName, Phone, Email, ClientType) VALUES (?, ?, ?, ?)", connection))
        {
            insertClient.Parameters.AddWithValue("@fullName", "Иванов Иван Иванович");
            insertClient.Parameters.AddWithValue("@phone", "+7 (900) 111-11-11");
            insertClient.Parameters.AddWithValue("@email", "ivanov@example.com");
            insertClient.Parameters.AddWithValue("@type", "Покупатель");
            await insertClient.ExecuteNonQueryAsync();

            insertClient.Parameters.Clear();
            insertClient.Parameters.AddWithValue("@fullName", "Петров Петр Петрович");
            insertClient.Parameters.AddWithValue("@phone", "+7 (900) 222-22-22");
            insertClient.Parameters.AddWithValue("@email", "petrov@example.com");
            insertClient.Parameters.AddWithValue("@type", "Арендодатель");
            await insertClient.ExecuteNonQueryAsync();
        }

        // Объекты
        using (var insertProp = new OleDbCommand(
                   @"INSERT INTO Properties ([Address], PropertyType, Area, Rooms, Floor, Price, [Status], OwnerID)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)", connection))
        {
            insertProp.Parameters.AddWithValue("@address", "г. Москва, ул. Ленина, д. 1");
            insertProp.Parameters.AddWithValue("@type", "Квартира");
            insertProp.Parameters.AddWithValue("@area", 45.0);
            insertProp.Parameters.AddWithValue("@rooms", 2);
            insertProp.Parameters.AddWithValue("@floor", 3);
            insertProp.Parameters.AddWithValue("@price", 8500000m);
            insertProp.Parameters.AddWithValue("@status", "Активно");
            insertProp.Parameters.AddWithValue("@owner", 2); // Петров
            await insertProp.ExecuteNonQueryAsync();

            insertProp.Parameters.Clear();
            insertProp.Parameters.AddWithValue("@address", "г. Москва, пр-т Мира, д. 10");
            insertProp.Parameters.AddWithValue("@type", "Квартира");
            insertProp.Parameters.AddWithValue("@area", 60.0);
            insertProp.Parameters.AddWithValue("@rooms", 3);
            insertProp.Parameters.AddWithValue("@floor", 7);
            insertProp.Parameters.AddWithValue("@price", 12000000m);
            insertProp.Parameters.AddWithValue("@status", "Активно");
            insertProp.Parameters.AddWithValue("@owner", 2);
            await insertProp.ExecuteNonQueryAsync();
        }
    }

}
