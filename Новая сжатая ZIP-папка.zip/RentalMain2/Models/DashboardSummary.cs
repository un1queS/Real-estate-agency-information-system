namespace RentalMain2.Models;

public sealed class DashboardSummary
{
    public int ClientsCount { get; init; }
    public int PropertiesCount { get; init; }
    public int ActivePropertiesCount { get; init; }
    public int DealsCount { get; init; }
    public int DealsThisMonthCount { get; init; }
    public decimal DealsThisMonthAmount { get; init; }
    public int SalesDealsCount { get; init; }
    public int RentDealsCount { get; init; }
}
