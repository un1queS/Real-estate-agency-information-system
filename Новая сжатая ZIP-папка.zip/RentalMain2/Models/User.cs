﻿namespace RentalMain2.Models;

public sealed class User
{
    public int UserID { get; set; }
    public string Login { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string Role { get; set; } = "User";
    public bool CanEdit { get; set; }
    public bool IsActive { get; set; } = true;
}
