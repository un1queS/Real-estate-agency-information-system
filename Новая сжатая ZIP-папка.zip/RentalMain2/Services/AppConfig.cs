﻿using Microsoft.Extensions.Configuration;
using System.IO;

namespace RentalMain2.Services;

public sealed class AppConfig
{
    public string DatabasePath { get; }

    /// <summary>
    /// Если true и файла нет — приложение создаст пустую .accdb по указанному пути.
    /// Если false — при отсутствии файла будет ошибка (используйте готовую базу из папки проекта).
    /// </summary>
    public bool CreateIfMissing { get; }

    private AppConfig(string databasePath, bool createIfMissing)
    {
        DatabasePath = databasePath;
        CreateIfMissing = createIfMissing;
    }

    public static AppConfig Load()
    {
        IConfigurationRoot configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: true, reloadOnChange: false)
            .Build();

        bool createIfMissing = ParseCreateIfMissing(configuration["Database:CreateIfMissing"]);

        // 1) Путь из appsettings.json (абсолютный или относительно каталога exe).
        string configuredPath = configuration["Database:Path"] ?? "../../../../RentalMain2.accdb";
        string configuredFullPath = Path.IsPathRooted(configuredPath)
            ? Path.GetFullPath(configuredPath)
            : Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, configuredPath));

        if (TryResolveExistingAccessFile(configuredFullPath, out string? resolvedFromConfig))
        {
            return new AppConfig(resolvedFromConfig, createIfMissing);
        }

        // 2) Ищем .accdb в корне проекта (на уровень выше bin).
        string projectRoot = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../"));
        if (Directory.Exists(projectRoot))
        {
            string preferred = Path.Combine(projectRoot, "RentalMain2.accdb");
            if (File.Exists(preferred))
            {
                return new AppConfig(preferred, createIfMissing);
            }

            string? anyDb = Directory.GetFiles(projectRoot, "*.accdb").OrderBy(Path.GetFileName).FirstOrDefault();
            if (!string.IsNullOrWhiteSpace(anyDb))
            {
                return new AppConfig(anyDb, createIfMissing);
            }
        }

        // 3) Фолбэк: путь из конфига как задан (создание — только если CreateIfMissing=true).
        return new AppConfig(configuredFullPath, createIfMissing);
    }

    private static bool ParseCreateIfMissing(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return true;
        }

        return bool.TryParse(value, out bool parsed) ? parsed : true;
    }

    /// <summary>
    /// Находит существующий файл: точное совпадение, то же имя без учёта регистра, или единственный .accdb в папке.
    /// </summary>
    private static bool TryResolveExistingAccessFile(string configuredFullPath, out string? resolvedPath)
    {
        resolvedPath = null;
        configuredFullPath = Path.GetFullPath(configuredFullPath);

        if (File.Exists(configuredFullPath))
        {
            resolvedPath = configuredFullPath;
            return true;
        }

        string? directory = Path.GetDirectoryName(configuredFullPath);
        string targetName = Path.GetFileName(configuredFullPath);
        if (string.IsNullOrEmpty(directory) || !Directory.Exists(directory))
        {
            return false;
        }

        string[] files = Directory.GetFiles(directory, "*.accdb", SearchOption.TopDirectoryOnly);
        foreach (string file in files)
        {
            if (string.Equals(Path.GetFileName(file), targetName, StringComparison.OrdinalIgnoreCase))
            {
                resolvedPath = Path.GetFullPath(file);
                return true;
            }
        }

        if (files.Length == 1)
        {
            resolvedPath = Path.GetFullPath(files[0]);
            return true;
        }

        return false;
    }
}
